package com.englishkhmer.translator;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.Surface;
import android.widget.*;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int PICK_PHOTO = 72;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private Spinner englishVoice, khmerVoice, videoSize;
    private EditText combinedText;
    private LinearLayout previewCard;
    private TextView previewText, status;
    private Button generateBtn, exportBtn, clearBtn, pasteBtn;
    private int backgroundColor = Color.WHITE;
    private Uri backgroundPhoto;
    private final List<Voice> enVoices = new ArrayList<>();
    private final List<Voice> kmVoices = new ArrayList<>();
    private volatile boolean isExporting = false;

    private static class LineSegment {
        final String text;
        final boolean isKhmer;
        long startUs;
        long endUs;
        short[] pcm44k;

        LineSegment(String text, boolean isKhmer) {
            this.text = text;
            this.isKhmer = isKhmer;
        }
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        tts = new TextToSpeech(this, result -> {
            ttsReady = result == TextToSpeech.SUCCESS;
            if (ttsReady) runOnUiThread(this::loadVoices);
            else runOnUiThread(() -> status.setText("Text-to-speech is unavailable on this phone."));
        });
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 36);
        root.setBackgroundColor(Color.rgb(244, 247, 252));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("English Khmer Video Maker");
        title.setTextSize(23);
        title.setTextColor(Color.rgb(25, 65, 145));
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Synced voice highlight & MP4 export");
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 6, 0, 18);
        root.addView(sub);

        section(root, "1. English & Khmer Text");
        combinedText = new EditText(this);
        combinedText.setHint("Hello\nសួរស្ដី\nHow are you?\nតើអ្នកសុខសប្បាយទេ?");
        combinedText.setTextSize(17);
        combinedText.setMinLines(5);
        combinedText.setMaxLines(12);
        combinedText.setGravity(Gravity.TOP | Gravity.START);
        combinedText.setBackgroundColor(Color.WHITE);
        combinedText.setPadding(20, 18, 20, 18);
        root.addView(combinedText);

        LinearLayout textActions = new LinearLayout(this);
        textActions.setOrientation(LinearLayout.HORIZONTAL);
        textActions.setPadding(0, 8, 0, 4);

        pasteBtn = button("Paste");
        pasteBtn.setOnClickListener(v -> {
            if (isExporting) return;
            pasteInto(combinedText);
            renderLivePreviewHighlight(-1);
        });
        textActions.addView(pasteBtn, new LinearLayout.LayoutParams(0, -2, 1));

        clearBtn = button("Clear");
        clearBtn.setOnClickListener(v -> {
            if (isExporting) return;
            if (tts != null) tts.stop();
            combinedText.setText("");
            previewText.setText("");
            backgroundPhoto = null;
            backgroundColor = Color.WHITE;
            updatePreviewBackground();
            status.setText("Cleared.");
        });
        textActions.addView(clearBtn, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(textActions);

        section(root, "2. Voices (English & Khmer)");
        TextView enLabel = new TextView(this);
        enLabel.setText("English Voice:");
        enLabel.setTextSize(14);
        root.addView(enLabel);
        englishVoice = new Spinner(this);
        root.addView(englishVoice);

        TextView kmLabel = new TextView(this);
        kmLabel.setText("Khmer Voice:");
        kmLabel.setTextSize(14);
        kmLabel.setPadding(0, 8, 0, 0);
        root.addView(kmLabel);
        khmerVoice = new Spinner(this);
        root.addView(khmerVoice);

        section(root, "3. Video Size");
        videoSize = new Spinner(this);
        videoSize.setAdapter(adapter(new String[]{
                "9:16 (Shorts / TikTok)",
                "16:9 (YouTube)",
                "1:1 (Square)",
                "3:4 (Portrait)"
        }));
        root.addView(videoSize);

        section(root, "4. Background");
        LinearLayout colors = new LinearLayout(this);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        int[] palette = {Color.WHITE, Color.BLACK, Color.rgb(20, 65, 130), Color.rgb(255, 220, 80), Color.rgb(225, 235, 245)};
        String[] names = {"White", "Black", "Blue", "Yellow", "Light"};
        for (int i = 0; i < palette.length; i++) {
            final int c = palette[i];
            Button b = button(names[i]);
            b.setOnClickListener(v -> {
                backgroundColor = c;
                backgroundPhoto = null;
                updatePreviewBackground();
                renderLivePreviewHighlight(-1);
            });
            colors.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(colors);

        Button photo = button("Add photo background");
        root.addView(photo);
        photo.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Choose background photo"), PICK_PHOTO);
        });

        section(root, "5. Video Preview (Synced Highlight)");
        previewCard = new LinearLayout(this);
        previewCard.setOrientation(LinearLayout.VERTICAL);
        previewCard.setGravity(Gravity.CENTER);
        previewCard.setPadding(24, 36, 24, 36);

        previewText = new TextView(this);
        previewText.setTextSize(21);
        previewText.setGravity(Gravity.CENTER);
        previewText.setLineSpacing(10f, 1.15f);
        previewCard.addView(previewText);
        root.addView(previewCard);
        updatePreviewBackground();

        generateBtn = button("Preview Voices & Highlight");
        root.addView(generateBtn);
        generateBtn.setOnClickListener(v -> generateLivePreview());

        exportBtn = button("Export MP4 Video");
        exportBtn.setBackgroundColor(Color.rgb(22, 160, 133));
        exportBtn.setTextColor(Color.WHITE);
        root.addView(exportBtn);
        exportBtn.setOnClickListener(v -> startExportMp4());

        status = new TextView(this);
        status.setText("Ready. Paste or type alternating English & Khmer lines.");
        status.setPadding(0, 18, 0, 0);
        root.addView(status);
        setContentView(scroll);
    }

    private boolean containsKhmer(String text) {
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if ((ch >= '\u1780' && ch <= '\u17FF') || (ch >= '\u19E0' && ch <= '\u19FF')) {
                return true;
            }
        }
        return false;
    }

    private List<LineSegment> parseLines(String raw) {
        List<LineSegment> list = new ArrayList<>();
        if (raw == null) return list;
        String[] split = raw.split("\r?\n");
        for (String s : split) {
            String trimmed = s.trim();
            if (!trimmed.isEmpty()) {
                list.add(new LineSegment(trimmed, containsKhmer(trimmed)));
            }
        }
        return list;
    }

    private void renderLivePreviewHighlight(int activeIndex) {
        List<LineSegment> lines = parseLines(combinedText.getText().toString());
        if (lines.isEmpty()) {
            previewText.setText("");
            return;
        }
        boolean darkBg = (backgroundColor == Color.BLACK || backgroundColor == Color.rgb(20, 65, 130));
        int normalColor = darkBg ? Color.WHITE : Color.BLACK;
        int dimColor = darkBg ? Color.argb(150, 255, 255, 255) : Color.argb(140, 0, 0, 0);
        int highlightBg = Color.rgb(255, 214, 10);
        int highlightFg = Color.BLACK;

        SpannableStringBuilder ssb = new SpannableStringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            LineSegment seg = lines.get(i);
            int start = ssb.length();
            ssb.append(seg.text);
            int end = ssb.length();

            if (i == activeIndex) {
                ssb.setSpan(new BackgroundColorSpan(highlightBg), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                ssb.setSpan(new ForegroundColorSpan(highlightFg), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                ssb.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else {
                int c = (activeIndex >= 0) ? dimColor : normalColor;
                ssb.setSpan(new ForegroundColorSpan(c), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (!seg.isKhmer) {
                    ssb.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
            if (i < lines.size() - 1) ssb.append("\n");
        }
        previewText.setText(ssb);
    }

    private void loadVoices() {
        enVoices.clear();
        kmVoices.clear();
        Set<Voice> all = tts.getVoices();
        if (all != null) {
            for (Voice voice : all) {
                String lang = voice.getLocale().getLanguage();
                if ("en".equals(lang)) enVoices.add(voice);
                if ("km".equals(lang)) kmVoices.add(voice);
            }
        }
        englishVoice.setAdapter(adapter(voiceNames(enVoices, "English voice")));
        khmerVoice.setAdapter(adapter(voiceNames(kmVoices, "Khmer voice")));
        if (kmVoices.isEmpty()) {
            status.setText("No Khmer TTS voice installed. Install Google Speech Services Khmer voice in Android Settings.");
        }
    }

    private List<String> voiceNames(List<Voice> voices, String fallback) {
        List<String> names = new ArrayList<>();
        for (Voice v : voices) names.add(v.getName() + " (" + v.getLocale().toLanguageTag() + ")");
        if (names.isEmpty()) names.add("No " + fallback + " available on this device");
        return names;
    }

    private void generateLivePreview() {
        if (isExporting) return;
        List<LineSegment> lines = parseLines(combinedText.getText().toString());
        if (lines.isEmpty()) {
            status.setText("Enter or paste English and Khmer text first.");
            return;
        }
        renderLivePreviewHighlight(-1);
        if (!ttsReady) {
            status.setText("Speech engine is still loading.");
            return;
        }
        final Voice ev = selected(enVoices, englishVoice);
        final Voice kv = selected(kmVoices, khmerVoice);

        tts.stop();
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                if (utteranceId != null && utteranceId.startsWith("line_")) {
                    try {
                        int idx = Integer.parseInt(utteranceId.substring(5));
                        runOnUiThread(() -> renderLivePreviewHighlight(idx));
                    } catch (Exception ignored) {}
                }
            }

            @Override
            public void onDone(String utteranceId) {
                if (utteranceId != null && utteranceId.equals("line_" + (lines.size() - 1))) {
                    runOnUiThread(() -> {
                        renderLivePreviewHighlight(-1);
                        status.setText("Preview finished.");
                    });
                }
            }

            @Override
            public void onError(String utteranceId) {}
        });

        boolean spokeAny = false;
        for (int i = 0; i < lines.size(); i++) {
            LineSegment seg = lines.get(i);
            Voice v = seg.isKhmer ? kv : ev;
            if (v != null) {
                tts.setVoice(v);
                int mode = spokeAny ? TextToSpeech.QUEUE_ADD : TextToSpeech.QUEUE_FLUSH;
                tts.speak(seg.text, mode, null, "line_" + i);
                spokeAny = true;
            }
        }
        if (spokeAny) {
            status.setText("Playing synced voice & text highlight...");
        } else {
            status.setText("No matching TTS voice available on this device.");
        }
    }

    private void startExportMp4() {
        if (isExporting) return;
        final List<LineSegment> lines = parseLines(combinedText.getText().toString());
        if (lines.isEmpty()) {
            status.setText("Enter or paste English and Khmer text first before exporting MP4.");
            return;
        }
        renderLivePreviewHighlight(-1);

        final int ratioIdx = videoSize.getSelectedItemPosition();
        final Voice ev = selected(enVoices, englishVoice);
        final Voice kv = selected(kmVoices, khmerVoice);
        final int bgCol = backgroundColor;
        final Uri bgUri = backgroundPhoto;

        isExporting = true;
        exportBtn.setEnabled(false);
        generateBtn.setEnabled(false);
        status.setText("Synthesizing voices & rendering synced MP4... Please wait.");

        new Thread(() -> {
            File tempMp4 = null;
            try {
                int width = 720, height = 1280;
                if (ratioIdx == 1) { width = 1280; height = 720; }      // 16:9
                else if (ratioIdx == 2) { width = 1080; height = 1080; } // 1:1
                else if (ratioIdx == 3) { width = 900; height = 1200; }  // 3:4

                int targetSampleRate = 44100;
                List<Short> mergedMonoPcm = new ArrayList<>();

                // 0.35s lead-in before first line
                int leadSamples = (int) (targetSampleRate * 0.35);
                for (int i = 0; i < leadSamples; i++) mergedMonoPcm.add((short) 0);

                // Synthesize each line individually and record its exact [startUs, endUs] timestamp!
                for (int i = 0; i < lines.size(); i++) {
                    LineSegment seg = lines.get(i);
                    Voice chosenVoice = seg.isKhmer ? kv : ev;
                    short[] linePcm = null;

                    if (ttsReady && chosenVoice != null) {
                        File wavFile = new File(getCacheDir(), "line_" + i + "_" + System.nanoTime() + ".wav");
                        try {
                            if (synthesizeToWav(seg.text, chosenVoice, wavFile)) {
                                WavData wd = readWav(wavFile);
                                linePcm = resampleToMono44k(wd, targetSampleRate);
                            }
                        } finally {
                            if (wavFile.exists()) wavFile.delete();
                        }
                    }

                    // Fallback duration if TTS voice wasn't available for that line (based on character count)
                    if (linePcm == null || linePcm.length == 0) {
                        int fallbackSamples = (int) (targetSampleRate * Math.max(1.2, seg.text.length() * 0.08));
                        linePcm = new short[fallbackSamples];
                    }

                    long startSample = mergedMonoPcm.size();
                    for (short s : linePcm) mergedMonoPcm.add(s);
                    long endSample = mergedMonoPcm.size();

                    seg.startUs = (startSample * 1_000_000L) / targetSampleRate;
                    seg.endUs = (endSample * 1_000_000L) / targetSampleRate;

                    // 0.25s natural pause between lines
                    if (i < lines.size() - 1) {
                        int pauseSamples = (int) (targetSampleRate * 0.25);
                        for (int p = 0; p < pauseSamples; p++) mergedMonoPcm.add((short) 0);
                    }
                }

                // 0.5s tail silence
                int tailSamples = (int) (targetSampleRate * 0.5);
                for (int i = 0; i < tailSamples; i++) mergedMonoPcm.add((short) 0);

                // Pre-load background photo bitmap once if chosen
                Bitmap bgPhotoBitmap = null;
                if (bgUri != null) {
                    try (InputStream is = getContentResolver().openInputStream(bgUri)) {
                        bgPhotoBitmap = BitmapFactory.decodeStream(is);
                    } catch (Exception ignored) {}
                }

                tempMp4 = new File(getCacheDir(), "export_" + System.currentTimeMillis() + ".mp4");
                encodeSyncedVideoAndAudioToMp4(width, height, lines, bgCol, bgPhotoBitmap, mergedMonoPcm, targetSampleRate, tempMp4);

                if (bgPhotoBitmap != null) bgPhotoBitmap.recycle();

                String savedName = "EK_Synced_" + System.currentTimeMillis() + ".mp4";
                String savedLocation = saveMp4ToMovies(tempMp4, savedName);

                runOnUiThread(() -> {
                    isExporting = false;
                    exportBtn.setEnabled(true);
                    generateBtn.setEnabled(true);
                    renderLivePreviewHighlight(-1);
                    status.setText("MP4 Saved: " + savedLocation);
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("MP4 Export Complete")
                            .setMessage("Video with synced voice highlight saved to Gallery / Movies:\n" + savedLocation)
                            .setPositiveButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                e.printStackTrace();
                final String err = e.getMessage() != null ? e.getMessage() : e.toString();
                runOnUiThread(() -> {
                    isExporting = false;
                    exportBtn.setEnabled(true);
                    generateBtn.setEnabled(true);
                    status.setText("Export failed: " + err);
                });
            } finally {
                if (tempMp4 != null && tempMp4.exists()) tempMp4.delete();
            }
        }).start();
    }

    private short[] resampleToMono44k(WavData wd, int targetSampleRate) {
        int monoFrames = wd.pcm.length / wd.channels;
        if (monoFrames <= 0) return new short[0];
        double ratio = (double) wd.sampleRate / targetSampleRate;
        int outLen = (int) (monoFrames / ratio);
        short[] out = new short[outLen];
        for (int i = 0; i < outLen; i++) {
            int srcFrame = Math.min(monoFrames - 1, (int) (i * ratio));
            int sum = 0;
            for (int c = 0; c < wd.channels; c++) {
                sum += wd.pcm[srcFrame * wd.channels + c];
            }
            out[i] = (short) (sum / wd.channels);
        }
        return out;
    }

    private boolean synthesizeToWav(String text, Voice voice, File outFile) {
        try {
            final CountDownLatch latch = new CountDownLatch(1);
            final boolean[] success = {false};
            final String uttId = "synth_" + System.nanoTime();

            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) {
                    if (uttId.equals(utteranceId)) {
                        success[0] = true;
                        latch.countDown();
                    }
                }
                @Override public void onError(String utteranceId) {
                    if (uttId.equals(utteranceId)) latch.countDown();
                }
            });

            tts.setVoice(voice);
            int res = tts.synthesizeToFile(text, new Bundle(), outFile, uttId);
            if (res != TextToSpeech.SUCCESS) return false;
            latch.await(25, TimeUnit.SECONDS);
            return success[0] && outFile.exists() && outFile.length() > 44;
        } catch (Exception e) {
            return false;
        }
    }

    private Bitmap renderFrameForTimestamp(int width, int height, List<LineSegment> lines, int activeLineIdx, int bgCol, Bitmap bgPhoto) {
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.drawColor(bgCol);

        if (bgPhoto != null) {
            float scale = Math.max((float) width / bgPhoto.getWidth(), (float) height / bgPhoto.getHeight());
            float newW = bgPhoto.getWidth() * scale;
            float newH = bgPhoto.getHeight() * scale;
            float left = (width - newW) / 2f;
            float top = (height - newH) / 2f;
            RectF dst = new RectF(left, top, left + newW, top + newH);
            canvas.drawBitmap(bgPhoto, null, dst, new Paint(Paint.FILTER_BITMAP_FLAG));

            Paint dim = new Paint();
            dim.setColor(Color.argb(110, 0, 0, 0));
            canvas.drawRect(0, 0, width, height, dim);
        }

        boolean darkBg = (bgPhoto != null || bgCol == Color.BLACK || bgCol == Color.rgb(20, 65, 130));
        int normalFg = darkBg ? Color.WHITE : Color.BLACK;
        int dimFg = darkBg ? Color.argb(155, 255, 255, 255) : Color.argb(145, 0, 0, 0);
        int highlightBoxColor = Color.rgb(255, 214, 10); // Bright yellow highlight pill
        int highlightTextColor = Color.BLACK;

        int padX = (int) (width * 0.08f);
        int textWidth = width - (padX * 2);
        float baseFontSize = Math.max(34f, width * 0.048f);
        if (lines.size() > 6) baseFontSize *= 0.82f;
        if (lines.size() > 10) baseFontSize *= 0.75f;

        List<StaticLayout> layouts = new ArrayList<>();
        float lineSpacing = baseFontSize * 0.48f;
        float totalHeight = 0f;

        for (int i = 0; i < lines.size(); i++) {
            LineSegment seg = lines.get(i);
            boolean isActive = (i == activeLineIdx);

            TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            tp.setTextSize(seg.isKhmer ? baseFontSize * 1.05f : baseFontSize);
            tp.setColor(isActive ? highlightTextColor : (activeLineIdx >= 0 ? dimFg : normalFg));
            if (isActive || !seg.isKhmer) {
                tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            }

            StaticLayout sl = StaticLayout.Builder.obtain(seg.text, 0, seg.text.length(), tp, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .build();
            layouts.add(sl);
            totalHeight += sl.getHeight();
            if (i < lines.size() - 1) totalHeight += lineSpacing;
        }

        float curY = Math.max(padX, (height - totalHeight) / 2f);
        Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        boxPaint.setColor(highlightBoxColor);

        for (int i = 0; i < lines.size(); i++) {
            StaticLayout sl = layouts.get(i);
            float lh = sl.getHeight();

            if (i == activeLineIdx) {
                // Measure tightest text line width for a clean rounded highlight badge
                float maxLineW = 0f;
                for (int l = 0; l < sl.getLineCount(); l++) {
                    maxLineW = Math.max(maxLineW, sl.getLineWidth(l));
                }
                float boxPadX = 24f;
                float boxPadY = 10f;
                float boxLeft = Math.max(padX - 12f, (width - maxLineW) / 2f - boxPadX);
                float boxRight = Math.min(width - padX + 12f, (width + maxLineW) / 2f + boxPadX);
                RectF pill = new RectF(boxLeft, curY - boxPadY, boxRight, curY + lh + boxPadY);
                canvas.drawRoundRect(pill, 18f, 18f, boxPaint);
            }

            canvas.save();
            canvas.translate(padX, curY);
            sl.draw(canvas);
            canvas.restore();

            curY += lh + lineSpacing;
        }
        return bmp;
    }

    private static class WavData {
        short[] pcm;
        int sampleRate;
        int channels;
    }

    private WavData readWav(File file) throws IOException {
        byte[] bytes = new byte[(int) file.length()];
        try (FileInputStream fis = new FileInputStream(file)) {
            int offset = 0;
            while (offset < bytes.length) {
                int r = fis.read(bytes, offset, bytes.length - offset);
                if (r < 0) break;
                offset += r;
            }
        }
        ByteBuffer bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        int channels = 1;
        int sampleRate = 22050;
        int dataOffset = 44;
        int dataSize = bytes.length - 44;

        int pos = 12;
        while (pos + 8 <= bytes.length) {
            int chunkId = bb.getInt(pos);
            int chunkSize = bb.getInt(pos + 4);
            if (chunkId == 0x20746d66) {
                channels = bb.getShort(pos + 10) & 0xFFFF;
                sampleRate = bb.getInt(pos + 12);
            } else if (chunkId == 0x61746164) {
                dataOffset = pos + 8;
                dataSize = Math.min(chunkSize, bytes.length - dataOffset);
                break;
            }
            pos += 8 + chunkSize + (chunkSize % 2);
        }

        int numSamples = Math.max(0, dataSize / 2);
        short[] samples = new short[numSamples];
        bb.position(dataOffset);
        for (int i = 0; i < numSamples; i++) {
            samples[i] = bb.getShort();
        }
        WavData wd = new WavData();
        wd.pcm = samples;
        wd.sampleRate = sampleRate > 0 ? sampleRate : 22050;
        wd.channels = channels > 0 ? channels : 1;
        return wd;
    }

    private void encodeSyncedVideoAndAudioToMp4(int width, int height, List<LineSegment> lines, int bgCol, Bitmap bgPhoto,
                                                 List<Short> mergedMonoPcm, int targetSampleRate, File outputMp4) throws Exception {
        long durationUs = (mergedMonoPcm.size() * 1_000_000L) / targetSampleRate;
        int fps = 15;
        int totalVideoFrames = Math.max(15, (int) ((durationUs * fps) / 1_000_000L));

        // Pre-render bitmaps for each highlight state:
        // key -1 = no active highlight, key 0..N-1 = line i highlighted
        Map<Integer, Bitmap> stateBitmaps = new HashMap<>();
        stateBitmaps.put(-1, renderFrameForTimestamp(width, height, lines, -1, bgCol, bgPhoto));
        for (int i = 0; i < lines.size(); i++) {
            stateBitmaps.put(i, renderFrameForTimestamp(width, height, lines, i, bgCol, bgPhoto));
        }

        MediaMuxer muxer = new MediaMuxer(outputMp4.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

        MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000);
        videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

        MediaCodec videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        Surface inputSurface = videoEncoder.createInputSurface();
        videoEncoder.start();

        MediaFormat audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, targetSampleRate, 1);
        audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 96_000);
        audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);

        MediaCodec audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        audioEncoder.start();

        List<ByteBuffer> videoSamples = new ArrayList<>();
        List<MediaCodec.BufferInfo> videoInfos = new ArrayList<>();
        final MediaFormat[] finalVFormat = {null};
        MediaCodec.BufferInfo vInfo = new MediaCodec.BufferInfo();

        for (int frame = 0; frame < totalVideoFrames; frame++) {
            long framePtsUs = (frame * 1_000_000L) / fps;
            int activeIdx = -1;
            for (int i = 0; i < lines.size(); i++) {
                LineSegment seg = lines.get(i);
                if (framePtsUs >= seg.startUs && framePtsUs <= seg.endUs) {
                    activeIdx = i;
                    break;
                }
            }

            Bitmap frameBmp = stateBitmaps.get(activeIdx);
            Canvas c = inputSurface.lockCanvas(null);
            c.drawBitmap(frameBmp, 0, 0, null);
            inputSurface.unlockCanvasAndPost(c);

            drainEncoder(videoEncoder, vInfo, false, videoSamples, videoInfos, fmt -> finalVFormat[0] = fmt);
        }
        videoEncoder.signalEndOfInputStream();
        drainEncoder(videoEncoder, vInfo, true, videoSamples, videoInfos, fmt -> finalVFormat[0] = fmt);
        videoEncoder.stop();
        videoEncoder.release();
        inputSurface.release();

        for (Bitmap b : stateBitmaps.values()) {
            if (b != null && !b.isRecycled()) b.recycle();
        }

        List<ByteBuffer> audioSamples = new ArrayList<>();
        List<MediaCodec.BufferInfo> audioInfos = new ArrayList<>();
        final MediaFormat[] finalAFormat = {null};
        MediaCodec.BufferInfo aInfo = new MediaCodec.BufferInfo();

        int pcmCursor = 0;
        int totalPcm = mergedMonoPcm.size();
        boolean audioInputDone = false;
        boolean audioOutputDone = false;

        while (!audioOutputDone) {
            if (!audioInputDone) {
                int inIdx = audioEncoder.dequeueInputBuffer(10_000);
                if (inIdx >= 0) {
                    ByteBuffer inBuf = audioEncoder.getInputBuffer(inIdx);
                    inBuf.clear();
                    int maxSamples = inBuf.remaining() / 2;
                    int count = Math.min(maxSamples, totalPcm - pcmCursor);
                    long ptsUs = (pcmCursor * 1_000_000L) / targetSampleRate;
                    if (count > 0) {
                        for (int i = 0; i < count; i++) {
                            inBuf.putShort(mergedMonoPcm.get(pcmCursor + i));
                        }
                        pcmCursor += count;
                        audioEncoder.queueInputBuffer(inIdx, 0, count * 2, ptsUs, 0);
                    } else {
                        audioEncoder.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        audioInputDone = true;
                    }
                }
            }

            int outIdx = audioEncoder.dequeueOutputBuffer(aInfo, 10_000);
            if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                finalAFormat[0] = audioEncoder.getOutputFormat();
            } else if (outIdx >= 0) {
                ByteBuffer encoded = audioEncoder.getOutputBuffer(outIdx);
                if ((aInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && aInfo.size > 0) {
                    encoded.position(aInfo.offset);
                    encoded.limit(aInfo.offset + aInfo.size);
                    ByteBuffer copy = ByteBuffer.allocateDirect(aInfo.size);
                    copy.put(encoded);
                    copy.flip();

                    MediaCodec.BufferInfo infoCopy = new MediaCodec.BufferInfo();
                    infoCopy.set(0, aInfo.size, aInfo.presentationTimeUs, aInfo.flags);
                    audioSamples.add(copy);
                    audioInfos.add(infoCopy);
                }
                audioEncoder.releaseOutputBuffer(outIdx, false);
                if ((aInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    audioOutputDone = true;
                }
            }
        }
        audioEncoder.stop();
        audioEncoder.release();

        if (finalVFormat[0] == null) throw new RuntimeException("Video encoder did not produce output format.");
        int videoTrackIndex = muxer.addTrack(finalVFormat[0]);
        int audioTrackIndex = -1;
        if (finalAFormat[0] != null && !audioSamples.isEmpty()) {
            audioTrackIndex = muxer.addTrack(finalAFormat[0]);
        }
        muxer.start();

        for (int i = 0; i < videoSamples.size(); i++) {
            muxer.writeSampleData(videoTrackIndex, videoSamples.get(i), videoInfos.get(i));
        }
        if (audioTrackIndex >= 0) {
            for (int i = 0; i < audioSamples.size(); i++) {
                muxer.writeSampleData(audioTrackIndex, audioSamples.get(i), audioInfos.get(i));
            }
        }

        muxer.stop();
        muxer.release();
    }

    private interface FormatCallback {
        void onFormat(MediaFormat format);
    }

    private void drainEncoder(MediaCodec encoder, MediaCodec.BufferInfo info, boolean endOfStream,
                              List<ByteBuffer> outSamples, List<MediaCodec.BufferInfo> outInfos,
                              FormatCallback formatCallback) {
        while (true) {
            int outIdx = encoder.dequeueOutputBuffer(info, 10_000);
            if (outIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break;
            } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                formatCallback.onFormat(encoder.getOutputFormat());
            } else if (outIdx >= 0) {
                ByteBuffer encoded = encoder.getOutputBuffer(outIdx);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                    encoded.position(info.offset);
                    encoded.limit(info.offset + info.size);
                    ByteBuffer copy = ByteBuffer.allocateDirect(info.size);
                    copy.put(encoded);
                    copy.flip();

                    MediaCodec.BufferInfo infoCopy = new MediaCodec.BufferInfo();
                    long pts = outSamples.size() * (1_000_000L / 15L);
                    infoCopy.set(0, info.size, pts, info.flags);
                    outSamples.add(copy);
                    outInfos.add(infoCopy);
                }
                encoder.releaseOutputBuffer(outIdx, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }

    private String saveMp4ToMovies(File sourceMp4, String displayName) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/EnglishKhmerVideoMaker");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            ContentResolver resolver = getContentResolver();
            Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Could not create MediaStore video entry.");

            try (OutputStream os = resolver.openOutputStream(uri);
                 FileInputStream fis = new FileInputStream(sourceMp4)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) > 0) os.write(buf, 0, len);
            }

            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return "Movies/EnglishKhmerVideoMaker/" + displayName;
        } else {
            File moviesDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "EnglishKhmerVideoMaker");
            if (!moviesDir.exists()) moviesDir.mkdirs();
            File dest = new File(moviesDir, displayName);
            try (FileInputStream fis = new FileInputStream(sourceMp4);
                 FileOutputStream fos = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) > 0) fos.write(buf, 0, len);
            }
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(dest)));
            return dest.getAbsolutePath();
        }
    }

    private Voice selected(List<Voice> voices, Spinner spinner) {
        int pos = spinner.getSelectedItemPosition();
        return pos >= 0 && pos < voices.size() ? voices.get(pos) : null;
    }

    private void updatePreviewBackground() {
        previewCard.setBackgroundColor(backgroundColor);
        if (backgroundPhoto != null) {
            try {
                previewCard.setBackground(android.graphics.drawable.Drawable.createFromStream(
                        getContentResolver().openInputStream(backgroundPhoto), null));
            } catch (Exception ignored) {
                previewCard.setBackgroundColor(backgroundColor);
            }
        }
    }

    private void pasteInto(EditText target) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence value = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (value != null) target.setText(value);
        } else {
            status.setText("Clipboard is empty.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PHOTO && resultCode == RESULT_OK && data != null) {
            backgroundPhoto = data.getData();
            updatePreviewBackground();
            renderLivePreviewHighlight(-1);
            status.setText("Background photo selected.");
        }
    }

    private void section(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(17);
        t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(Color.rgb(35, 75, 145));
        t.setPadding(0, 20, 0, 8);
        root.addView(t);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private ArrayAdapter<String> adapter(List<String> values) {
        return new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
    }

    private ArrayAdapter<String> adapter(String[] values) {
        return new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
