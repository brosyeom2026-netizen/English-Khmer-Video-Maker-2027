package com.englishkhmer.translator;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.InputType;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Base64;
import android.view.Gravity;
import android.view.Surface;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int PICK_PHOTO = 72;
    private static final String PREFS_NAME = "ek_video_maker_prefs";
    private static final String KEY_GOOGLE_API = "google_tts_api_key";

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private EditText apiKeyInput, combinedText;
    private TextView apiStatusBadge, previewText, status;
    private Spinner englishVoice, khmerVoice, videoSize, voiceStyle;
    private LinearLayout previewCard;
    private Button generateBtn, exportBtn, clearBtn, pasteBtn, activateKeyBtn;
    private int backgroundColor = Color.WHITE;
    private Uri backgroundPhoto;
    private final List<VoiceOption> enVoiceOptions = new ArrayList<>();
    private final List<VoiceOption> kmVoiceOptions = new ArrayList<>();
    private volatile boolean isExporting = false;
    private MediaPlayer activeOnlinePlayer;
    private boolean apiKeyVerified = false;

    private static class VoiceOption {
        final String label;
        final Voice engineVoice;      // non-null for local device TTS
        final String googleCloudName; // e.g., "en-US-Chirp3-HD-Aoede" or "km-KH-Standard-A"
        final String langCode;        // e.g., "en-US" or "km-KH"
        final boolean isChirp3;       // Chirp 3 HD does not accept speakingRate/pitch overrides

        VoiceOption(String label, Voice engineVoice, String googleCloudName, String langCode, boolean isChirp3) {
            this.label = label;
            this.engineVoice = engineVoice;
            this.googleCloudName = googleCloudName;
            this.langCode = langCode;
            this.isChirp3 = isChirp3;
        }
    }

    private static class LineSegment {
        final String text;
        final boolean isKhmer;
        long startUs;
        long endUs;

        LineSegment(String text, boolean isKhmer) {
            this.text = text;
            this.isKhmer = isKhmer;
        }
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        loadSavedApiKey();
        tts = new TextToSpeech(this, result -> {
            ttsReady = result == TextToSpeech.SUCCESS;
            runOnUiThread(this::loadVoices);
        }, "com.google.android.tts");
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 36);
        root.setBackgroundColor(Color.rgb(244, 247, 252));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("English Khmer Video Maker");
        title.setTextSize(23);
        title.setTextColor(Color.rgb(25, 65, 145));
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Google API HD Voices • Synced Highlight • MP4 Export");
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 6, 0, 14);
        root.addView(sub);

        // --- SECTION 0: GOOGLE API KEY ACTIVE BOX ---
        section(root, "Google API Key (Active Box)");
        LinearLayout apiBox = new LinearLayout(this);
        apiBox.setOrientation(LinearLayout.VERTICAL);
        apiBox.setBackgroundColor(Color.WHITE);
        apiBox.setPadding(20, 18, 20, 18);

        apiStatusBadge = new TextView(this);
        apiStatusBadge.setText("● Status: Inactive (Using Free/Device Voices)");
        apiStatusBadge.setTextColor(Color.rgb(180, 95, 6));
        apiStatusBadge.setTypeface(null, Typeface.BOLD);
        apiStatusBadge.setTextSize(14);
        apiStatusBadge.setPadding(0, 0, 0, 10);
        apiBox.addView(apiStatusBadge);

        apiKeyInput = new EditText(this);
        apiKeyInput.setHint("Paste Google Cloud API Key (AIzaSy...)");
        apiKeyInput.setTextSize(15);
        apiKeyInput.setSingleLine(true);
        apiKeyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        apiKeyInput.setBackgroundColor(Color.rgb(245, 248, 253));
        apiKeyInput.setPadding(16, 14, 16, 14);
        apiBox.addView(apiKeyInput);

        LinearLayout apiBtnRow = new LinearLayout(this);
        apiBtnRow.setOrientation(LinearLayout.HORIZONTAL);
        apiBtnRow.setPadding(0, 10, 0, 0);

        Button pasteKeyBtn = button("Paste Key");
        pasteKeyBtn.setOnClickListener(v -> {
            pasteInto(apiKeyInput);
        });
        apiBtnRow.addView(pasteKeyBtn, new LinearLayout.LayoutParams(0, -2, 1));

        activateKeyBtn = button("Save & Activate");
        activateKeyBtn.setBackgroundColor(Color.rgb(35, 87, 198));
        activateKeyBtn.setTextColor(Color.WHITE);
        activateKeyBtn.setOnClickListener(v -> verifyAndActivateApiKey());
        apiBtnRow.addView(activateKeyBtn, new LinearLayout.LayoutParams(0, -2, 1.3f));

        Button clearKeyBtn = button("Clear");
        clearKeyBtn.setOnClickListener(v -> {
            apiKeyInput.setText("");
            apiKeyVerified = false;
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().remove(KEY_GOOGLE_API).apply();
            updateApiBadge(false, "Inactive (Cleared)");
            loadVoices();
            status.setText("Google API key cleared.");
        });
        apiBtnRow.addView(clearKeyBtn, new LinearLayout.LayoutParams(0, -2, 0.9f));

        apiBox.addView(apiBtnRow);
        root.addView(apiBox);

        // --- SECTION 1: COMBINED ENGLISH & KHMER TEXT ---
        section(root, "1. English & Khmer Text");
        combinedText = new EditText(this);
        combinedText.setHint("Hello\nសួរស្ដី\nHow are you?\nតើអ្នកសុខសប្បាយទេ?");
        combinedText.setTextSize(17);
        combinedText.setMinLines(5);
        combinedText.setMaxLines(12);
        combinedText.setGravity(Gravity.TOP | Gravity.START);
        combinedText.setBackgroundColor(Color.WHITE);
        combinedText.setPadding(20, 18, 20, 18);
        root.addView(combinedText);

        LinearLayout textActions = new LinearLayout(this);
        textActions.setOrientation(LinearLayout.HORIZONTAL);
        textActions.setPadding(0, 8, 0, 4);

        pasteBtn = button("Paste");
        pasteBtn.setOnClickListener(v -> {
            if (isExporting) return;
            pasteInto(combinedText);
            renderLivePreviewHighlight(-1);
        });
        textActions.addView(pasteBtn, new LinearLayout.LayoutParams(0, -2, 1));

        clearBtn = button("Clear");
        clearBtn.setOnClickListener(v -> {
            if (isExporting) return;
            stopAllAudio();
            combinedText.setText("");
            previewText.setText("");
            backgroundPhoto = null;
            backgroundColor = Color.WHITE;
            updatePreviewBackground();
            status.setText("Cleared.");
        });
        textActions.addView(clearBtn, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(textActions);

        // --- SECTION 2: VOICES ---
        section(root, "2. Google Real Voices & Tone");
        TextView enLabel = new TextView(this);
        enLabel.setText("English Voice:");
        enLabel.setTextSize(14);
        root.addView(enLabel);
        englishVoice = new Spinner(this);
        root.addView(englishVoice);

        TextView kmLabel = new TextView(this);
        kmLabel.setText("Khmer Voice:");
        kmLabel.setTextSize(14);
        kmLabel.setPadding(0, 8, 0, 0);
        root.addView(kmLabel);
        khmerVoice = new Spinner(this);
        root.addView(khmerVoice);

        TextView styleLabel = new TextView(this);
        styleLabel.setText("Speaking Style:");
        styleLabel.setTextSize(14);
        styleLabel.setPadding(0, 8, 0, 0);
        root.addView(styleLabel);
        voiceStyle = new Spinner(this);
        voiceStyle.setAdapter(adapter(new String[]{
                "Natural Conversational (Recommended)",
                "Slow & Clear (Teaching / Learning)",
                "Warm Storyteller (Deep & Calm)",
                "Energetic & Bright (Shorts / TikTok)"
        }));
        root.addView(voiceStyle);

        // --- SECTION 3: VIDEO SIZE ---
        section(root, "3. Video Size");
        videoSize = new Spinner(this);
        videoSize.setAdapter(adapter(new String[]{
                "9:16 (Shorts / TikTok)",
                "16:9 (YouTube)",
                "1:1 (Square)",
                "3:4 (Portrait)"
        }));
        root.addView(videoSize);

        // --- SECTION 4: BACKGROUND ---
        section(root, "4. Background");
        LinearLayout colors = new LinearLayout(this);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        int[] palette = {Color.WHITE, Color.BLACK, Color.rgb(20, 65, 130), Color.rgb(255, 220, 80), Color.rgb(225, 235, 245)};
        String[] names = {"White", "Black", "Blue", "Yellow", "Light"};
        for (int i = 0; i < palette.length; i++) {
            final int c = palette[i];
            Button b = button(names[i]);
            b.setOnClickListener(v -> {
                backgroundColor = c;
                backgroundPhoto = null;
                updatePreviewBackground();
                renderLivePreviewHighlight(-1);
            });
            colors.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(colors);

        Button photo = button("Add photo background");
        root.addView(photo);
        photo.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Choose background photo"), PICK_PHOTO);
        });

        // --- SECTION 5: PREVIEW & EXPORT ---
        section(root, "5. Video Preview (Synced Highlight)");
        previewCard = new LinearLayout(this);
        previewCard.setOrientation(LinearLayout.VERTICAL);
        previewCard.setGravity(Gravity.CENTER);
        previewCard.setPadding(24, 36, 24, 36);

        previewText = new TextView(this);
        previewText.setTextSize(21);
        previewText.setGravity(Gravity.CENTER);
        previewText.setLineSpacing(10f, 1.15f);
        previewCard.addView(previewText);
        root.addView(previewCard);
        updatePreviewBackground();

        generateBtn = button("Preview Voices & Highlight");
        root.addView(generateBtn);
        generateBtn.setOnClickListener(v -> generateLivePreview());

        exportBtn = button("Export MP4 Video");
        exportBtn.setBackgroundColor(Color.rgb(22, 160, 133));
        exportBtn.setTextColor(Color.WHITE);
        root.addView(exportBtn);
        exportBtn.setOnClickListener(v -> startExportMp4());

        status = new TextView(this);
        status.setText("Ready. Activate your Google API key or use built-in voices.");
        status.setPadding(0, 18, 0, 0);
        root.addView(status);
        setContentView(scroll);
    }

    private void loadSavedApiKey() {
        String saved = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_GOOGLE_API, "");
        if (saved != null && !saved.trim().isEmpty()) {
            apiKeyInput.setText(saved.trim());
            apiKeyVerified = true;
            updateApiBadge(true, "ACTIVE (Google Cloud TTS Ready)");
        }
    }

    private void updateApiBadge(boolean active, String msg) {
        if (active) {
            apiStatusBadge.setText("● Status: " + msg);
            apiStatusBadge.setTextColor(Color.rgb(22, 145, 75));
        } else {
            apiStatusBadge.setText("● Status: " + msg);
            apiStatusBadge.setTextColor(Color.rgb(185, 70, 30));
        }
    }

    private String getActiveApiKey() {
        if (apiKeyInput == null) return "";
        return apiKeyInput.getText().toString().trim();
    }

    private void verifyAndActivateApiKey() {
        final String key = getActiveApiKey();
        if (key.isEmpty()) {
            updateApiBadge(false, "Please paste a Google API key first");
            return;
        }
        activateKeyBtn.setEnabled(false);
        updateApiBadge(false, "Checking Google Cloud TTS API...");

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                // Verify key against Google Cloud Text-to-Speech voices endpoint
                URL url = new URL("https://texttospeech.googleapis.com/v1/voices?key=" + URLEncoder.encode(key, "UTF-8"));
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(12000);
                int code = conn.getResponseCode();

                if (code == 200) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(KEY_GOOGLE_API, key).apply();
                    runOnUiThread(() -> {
                        apiKeyVerified = true;
                        activateKeyBtn.setEnabled(true);
                        updateApiBadge(true, "ACTIVE (Google Cloud TTS Verified)");
                        loadVoices();
                        status.setText("Google Cloud API Key activated! Studio & Chirp 3 HD voices unlocked.");
                    });
                } else {
                    String errDetail = readStream(conn.getErrorStream());
                    String shortMsg = "Invalid Key or TTS API not enabled (HTTP " + code + ")";
                    try {
                        JSONObject errObj = new JSONObject(errDetail);
                        if (errObj.has("error")) {
                            shortMsg = errObj.getJSONObject("error").optString("message", shortMsg);
                        }
                    } catch (Exception ignored) {}
                    final String finalErr = shortMsg;
                    runOnUiThread(() -> {
                        apiKeyVerified = false;
                        activateKeyBtn.setEnabled(true);
                        updateApiBadge(false, "Error: " + finalErr);
                        status.setText("API Key error: " + finalErr);
                    });
                }
            } catch (Exception e) {
                final String msg = e.getMessage() != null ? e.getMessage() : "Network error";
                runOnUiThread(() -> {
                    apiKeyVerified = false;
                    activateKeyBtn.setEnabled(true);
                    updateApiBadge(false, "Connection failed: " + msg);
                });
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private String readStream(InputStream is) {
        if (is == null) return "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void applySpeakingStyle(int styleIdx) {
        if (!ttsReady || tts == null) return;
        if (styleIdx == 1) {
            tts.setSpeechRate(0.84f);
            tts.setPitch(1.00f);
        } else if (styleIdx == 2) {
            tts.setSpeechRate(0.92f);
            tts.setPitch(0.93f);
        } else if (styleIdx == 3) {
            tts.setSpeechRate(1.05f);
            tts.setPitch(1.05f);
        } else {
            tts.setSpeechRate(0.96f);
            tts.setPitch(0.98f);
        }
    }

    private void loadVoices() {
        enVoiceOptions.clear();
        kmVoiceOptions.clear();

        String key = getActiveApiKey();
        boolean hasKey = !key.isEmpty();

        // 1. If Google API Key is entered, put Official Google Cloud Real Voices at the very top!
        if (hasKey) {
            // English Google Cloud Voices (Chirp 3 HD, Studio, Neural2)
            enVoiceOptions.add(new VoiceOption("★ Google Cloud: Aoede — Female (Chirp 3 HD)", null, "en-US-Chirp3-HD-Aoede", "en-US", true));
            enVoiceOptions.add(new VoiceOption("★ Google Cloud: Fenrir — Male (Chirp 3 HD)", null, "en-US-Chirp3-HD-Fenrir", "en-US", true));
            enVoiceOptions.add(new VoiceOption("★ Google Cloud: Kore — Female (Chirp 3 HD)", null, "en-US-Chirp3-HD-Kore", "en-US", true));
            enVoiceOptions.add(new VoiceOption("★ Google Cloud: Puck — Male (Chirp 3 HD)", null, "en-US-Chirp3-HD-Puck", "en-US", true));
            enVoiceOptions.add(new VoiceOption("★ Google Cloud: Studio-O — Female (Broadcast)", null, "en-US-Studio-O", "en-US", false));
            enVoiceOptions.add(new VoiceOption("★ Google Cloud: Studio-Q — Male (Broadcast)", null, "en-US-Studio-Q", "en-US", false));
            enVoiceOptions.add(new VoiceOption("★ Google Cloud: Neural2-F — Female (Natural)", null, "en-US-Neural2-F", "en-US", false));
            enVoiceOptions.add(new VoiceOption("★ Google Cloud: Neural2-D — Male (Natural)", null, "en-US-Neural2-D", "en-US", false));

            // Khmer Google Cloud Voices (km-KH)
            kmVoiceOptions.add(new VoiceOption("★ Google Cloud: Khmer Female (km-KH-Standard-A)", null, "km-KH-Standard-A", "km-KH", false));
            kmVoiceOptions.add(new VoiceOption("★ Google Cloud: Khmer Chirp 3 HD — Aoede (km-KH)", null, "km-KH-Chirp3-HD-Aoede", "km-KH", true));
            kmVoiceOptions.add(new VoiceOption("★ Google Cloud: Khmer Chirp 3 HD — Fenrir (km-KH)", null, "km-KH-Chirp3-HD-Fenrir", "km-KH", true));
        }

        // 2. Also include Free Cloud Neural Voice & Device Installed Voices
        enVoiceOptions.add(new VoiceOption("Free Cloud Neural Voice (English)", null, null, "en", false));
        kmVoiceOptions.add(new VoiceOption("Free Cloud Neural Voice (Khmer • ភាសាខ្មែរ)", null, null, "km", false));

        if (ttsReady && tts != null) {
            Set<Voice> all = tts.getVoices();
            if (all != null) {
                for (Voice v : all) {
                    String lang = v.getLocale().getLanguage();
                    if ("en".equals(lang)) {
                        enVoiceOptions.add(new VoiceOption("Device Voice: " + v.getName() + " (" + v.getLocale().toLanguageTag() + ")", v, null, "en-US", false));
                    } else if ("km".equals(lang)) {
                        kmVoiceOptions.add(new VoiceOption("Device Voice: " + v.getName() + " (" + v.getLocale().toLanguageTag() + ")", v, null, "km-KH", false));
                    }
                }
            }
        }

        List<String> enLabels = new ArrayList<>();
        for (VoiceOption o : enVoiceOptions) enLabels.add(o.label);
        englishVoice.setAdapter(adapter(enLabels));

        List<String> kmLabels = new ArrayList<>();
        for (VoiceOption o : kmVoiceOptions) kmLabels.add(o.label);
        khmerVoice.setAdapter(adapter(kmLabels));
    }

    private boolean containsKhmer(String text) {
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if ((ch >= '\u1780' && ch <= '\u17FF') || (ch >= '\u19E0' && ch <= '\u19FF')) {
                return true;
            }
        }
        return false;
    }

    private List<LineSegment> parseLines(String raw) {
        List<LineSegment> list = new ArrayList<>();
        if (raw == null) return list;
        String[] split = raw.split("\r?\n");
        for (String s : split) {
            String trimmed = s.trim();
            if (!trimmed.isEmpty()) {
                list.add(new LineSegment(trimmed, containsKhmer(trimmed)));
            }
        }
        return list;
    }

    private void renderLivePreviewHighlight(int activeIndex) {
        List<LineSegment> lines = parseLines(combinedText.getText().toString());
        if (lines.isEmpty()) {
            previewText.setText("");
            return;
        }
        boolean darkBg = (backgroundColor == Color.BLACK || backgroundColor == Color.rgb(20, 65, 130));
        int normalColor = darkBg ? Color.WHITE : Color.BLACK;
        int dimColor = darkBg ? Color.argb(150, 255, 255, 255) : Color.argb(140, 0, 0, 0);
        int highlightBg = Color.rgb(255, 214, 10);
        int highlightFg = Color.BLACK;

        SpannableStringBuilder ssb = new SpannableStringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            LineSegment seg = lines.get(i);
            int start = ssb.length();
            ssb.append(seg.text);
            int end = ssb.length();

            if (i == activeIndex) {
                ssb.setSpan(new BackgroundColorSpan(highlightBg), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                ssb.setSpan(new ForegroundColorSpan(highlightFg), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                ssb.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else {
                int c = (activeIndex >= 0) ? dimColor : normalColor;
                ssb.setSpan(new ForegroundColorSpan(c), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (!seg.isKhmer) {
                    ssb.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
            if (i < lines.size() - 1) ssb.append("\n");
        }
        previewText.setText(ssb);
    }

    private void stopAllAudio() {
        if (tts != null) tts.stop();
        if (activeOnlinePlayer != null) {
            try {
                if (activeOnlinePlayer.isPlaying()) activeOnlinePlayer.stop();
                activeOnlinePlayer.release();
            } catch (Exception ignored) {}
            activeOnlinePlayer = null;
        }
    }

    private void generateLivePreview() {
        if (isExporting) return;
        final List<LineSegment> lines = parseLines(combinedText.getText().toString());
        if (lines.isEmpty()) {
            status.setText("Enter or paste English and Khmer text first.");
            return;
        }
        stopAllAudio();
        renderLivePreviewHighlight(-1);

        final VoiceOption enOpt = selectedOption(enVoiceOptions, englishVoice);
        final VoiceOption kmOpt = selectedOption(kmVoiceOptions, khmerVoice);
        final int styleIdx = voiceStyle.getSelectedItemPosition();
        final String apiKey = getActiveApiKey();

        status.setText("Synthesizing & playing synced voices...");

        new Thread(() -> {
            for (int i = 0; i < lines.size(); i++) {
                final int lineIdx = i;
                LineSegment seg = lines.get(i);
                VoiceOption opt = seg.isKhmer ? kmOpt : enOpt;
                if (opt == null) continue;

                runOnUiThread(() -> renderLivePreviewHighlight(lineIdx));

                boolean played = false;

                // 1. Try Official Google Cloud TTS API if a Google Cloud voice is selected and key is present
                if (opt.googleCloudName != null && !apiKey.isEmpty()) {
                    File cloudMp3 = new File(getCacheDir(), "gcloud_prev_" + lineIdx + "_" + System.nanoTime() + ".mp3");
                    try {
                        if (synthesizeWithGoogleCloudApi(seg.text, opt, styleIdx, apiKey, cloudMp3)) {
                            playAudioFileBlocking(cloudMp3);
                            played = true;
                        }
                    } finally {
                        if (cloudMp3.exists()) cloudMp3.delete();
                    }
                }

                // 2. Try Device TTS Engine if selected
                if (!played && opt.engineVoice != null && ttsReady) {
                    played = speakEngineLineBlocking(seg.text, opt.engineVoice, styleIdx);
                }

                // 3. Fallback to Free Cloud Neural TTS
                if (!played) {
                    File freeMp3 = new File(getCacheDir(), "free_prev_" + lineIdx + "_" + System.nanoTime() + ".mp3");
                    try {
                        String shortLang = seg.isKhmer ? "km" : "en";
                        if (downloadFreeCloudTtsMp3(seg.text, shortLang, freeMp3)) {
                            playAudioFileBlocking(freeMp3);
                        }
                    } finally {
                        if (freeMp3.exists()) freeMp3.delete();
                    }
                }

                try { Thread.sleep(220); } catch (InterruptedException ignored) {}
            }
            runOnUiThread(() -> {
                renderLivePreviewHighlight(-1);
                status.setText("Preview finished.");
            });
        }).start();
    }

    private boolean synthesizeWithGoogleCloudApi(String text, VoiceOption opt, int styleIdx, String apiKey, File outMp3) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://texttospeech.googleapis.com/v1/text:synthesize?key=" + URLEncoder.encode(apiKey, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(20000);

            JSONObject inputObj = new JSONObject();
            inputObj.put("text", text);

            JSONObject voiceObj = new JSONObject();
            voiceObj.put("languageCode", opt.langCode);
            voiceObj.put("name", opt.googleCloudName);

            JSONObject audioConfig = new JSONObject();
            audioConfig.put("audioEncoding", "MP3");
            if (!opt.isChirp3) {
                double rate = 0.98;
                double pitch = 0.0;
                if (styleIdx == 1) { rate = 0.84; pitch = 0.0; }
                else if (styleIdx == 2) { rate = 0.92; pitch = -1.5; }
                else if (styleIdx == 3) { rate = 1.06; pitch = 1.2; }
                audioConfig.put("speakingRate", rate);
                audioConfig.put("pitch", pitch);
            }

            JSONObject payload = new JSONObject();
            payload.put("input", inputObj);
            payload.put("voice", voiceObj);
            payload.put("audioConfig", audioConfig);

            byte[] bodyBytes = payload.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(bodyBytes);
            }

            int code = conn.getResponseCode();
            if (code != 200) {
                // If Chirp 3 HD isn't available for km-KH yet, automatically retry with km-KH-Standard-A
                if ("km-KH".equals(opt.langCode) && !"km-KH-Standard-A".equals(opt.googleCloudName)) {
                    VoiceOption fallbackKm = new VoiceOption(opt.label, null, "km-KH-Standard-A", "km-KH", false);
                    return synthesizeWithGoogleCloudApi(text, fallbackKm, styleIdx, apiKey, outMp3);
                }
                return false;
            }

            String resp = readStream(conn.getInputStream());
            JSONObject respJson = new JSONObject(resp);
            String audioBase64 = respJson.optString("audioContent", "");
            if (audioBase64.isEmpty()) return false;

            byte[] audioBytes = Base64.decode(audioBase64, Base64.DEFAULT);
            try (FileOutputStream fos = new FileOutputStream(outMp3)) {
                fos.write(audioBytes);
            }
            return outMp3.exists() && outMp3.length() > 256;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private boolean speakEngineLineBlocking(String text, Voice voice, int styleIdx) {
        try {
            final CountDownLatch latch = new CountDownLatch(1);
            final boolean[] ok = {false};
            final String uttId = "live_" + System.nanoTime();

            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) {
                    if (uttId.equals(utteranceId)) {
                        ok[0] = true;
                        latch.countDown();
                    }
                }
                @Override public void onError(String utteranceId) {
                    if (uttId.equals(utteranceId)) latch.countDown();
                }
            });

            applySpeakingStyle(styleIdx);
            tts.setVoice(voice);
            int res = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, uttId);
            if (res != TextToSpeech.SUCCESS) return false;
            latch.await(20, TimeUnit.SECONDS);
            return ok[0];
        } catch (Exception e) {
            return false;
        }
    }

    private void playAudioFileBlocking(File file) {
        try {
            final CountDownLatch latch = new CountDownLatch(1);
            MediaPlayer mp = new MediaPlayer();
            activeOnlinePlayer = mp;
            mp.setDataSource(file.getAbsolutePath());
            mp.setOnCompletionListener(m -> latch.countDown());
            mp.setOnErrorListener((m, what, extra) -> {
                latch.countDown();
                return true;
            });
            mp.prepare();
            mp.start();
            latch.await(25, TimeUnit.SECONDS);
            mp.release();
            if (activeOnlinePlayer == mp) activeOnlinePlayer = null;
        } catch (Exception ignored) {}
    }

    private boolean downloadFreeCloudTtsMp3(String text, String langCode, File outMp3) {
        HttpURLConnection conn = null;
        try {
            String encoded = URLEncoder.encode(text, "UTF-8");
            String urlStr = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=" + langCode + "&q=" + encoded;
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(15000);
            if (conn.getResponseCode() != 200) return false;

            try (InputStream is = conn.getInputStream();
                 FileOutputStream fos = new FileOutputStream(outMp3)) {
                byte[] buf = new byte[4096];
                int len;
                while ((len = is.read(buf)) > 0) fos.write(buf, 0, len);
            }
            return outMp3.exists() && outMp3.length() > 256;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private short[] decodeAudioFileToMono44k(File audioFile, int targetSampleRate) {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec decoder = null;
        try {
            extractor.setDataSource(audioFile.getAbsolutePath());
            int audioTrack = -1;
            MediaFormat format = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat mf = extractor.getTrackFormat(i);
                String mime = mf.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    format = mf;
                    break;
                }
            }
            if (audioTrack < 0 || format == null) return new short[0];

            extractor.selectTrack(audioTrack);
            String mime = format.getString(MediaFormat.KEY_MIME);
            int srcSampleRate = format.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                    ? format.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 24000;
            int srcChannels = format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                    ? format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;

            decoder = MediaCodec.createDecoderByType(mime);
            decoder.configure(format, null, null, 0);
            decoder.start();

            List<Short> rawSamples = new ArrayList<>();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean sawInputEOS = false;
            boolean sawOutputEOS = false;

            while (!sawOutputEOS) {
                if (!sawInputEOS) {
                    int inIdx = decoder.dequeueInputBuffer(10_000);
                    if (inIdx >= 0) {
                        ByteBuffer inBuf = decoder.getInputBuffer(inIdx);
                        int sampleSize = extractor.readSampleData(inBuf, 0);
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            sawInputEOS = true;
                        } else {
                            long pts = extractor.getSampleTime();
                            decoder.queueInputBuffer(inIdx, 0, sampleSize, pts, 0);
                            extractor.advance();
                        }
                    }
                }

                int outIdx = decoder.dequeueOutputBuffer(info, 10_000);
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat outFmt = decoder.getOutputFormat();
                    if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        srcSampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    }
                    if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        srcChannels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    }
                } else if (outIdx >= 0) {
                    ByteBuffer outBuf = decoder.getOutputBuffer(outIdx);
                    if (info.size > 0 && outBuf != null) {
                        outBuf.position(info.offset);
                        outBuf.limit(info.offset + info.size);
                        ShortBuffer sb = outBuf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer();
                        while (sb.hasRemaining()) {
                            rawSamples.add(sb.get());
                        }
                    }
                    decoder.releaseOutputBuffer(outIdx, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        sawOutputEOS = true;
                    }
                }
            }

            int monoFrames = rawSamples.size() / Math.max(1, srcChannels);
            if (monoFrames <= 0) return new short[0];
            double ratio = (double) srcSampleRate / targetSampleRate;
            int outLen = (int) (monoFrames / ratio);
            short[] resampled = new short[outLen];
            for (int i = 0; i < outLen; i++) {
                int srcFrame = Math.min(monoFrames - 1, (int) (i * ratio));
                int sum = 0;
                for (int c = 0; c < srcChannels; c++) {
                    sum += rawSamples.get(srcFrame * srcChannels + c);
                }
                resampled[i] = (short) (sum / srcChannels);
            }
            return resampled;
        } catch (Exception e) {
            return new short[0];
        } finally {
            if (decoder != null) {
                try { decoder.stop(); decoder.release(); } catch (Exception ignored) {}
            }
            extractor.release();
        }
    }

    private void startExportMp4() {
        if (isExporting) return;
        final List<LineSegment> lines = parseLines(combinedText.getText().toString());
        if (lines.isEmpty()) {
            status.setText("Enter or paste English and Khmer text first before exporting MP4.");
            return;
        }
        stopAllAudio();
        renderLivePreviewHighlight(-1);

        final int ratioIdx = videoSize.getSelectedItemPosition();
        final VoiceOption enOpt = selectedOption(enVoiceOptions, englishVoice);
        final VoiceOption kmOpt = selectedOption(kmVoiceOptions, khmerVoice);
        final int styleIdx = voiceStyle.getSelectedItemPosition();
        final int bgCol = backgroundColor;
        final Uri bgUri = backgroundPhoto;
        final String apiKey = getActiveApiKey();

        isExporting = true;
        exportBtn.setEnabled(false);
        generateBtn.setEnabled(false);
        status.setText("Synthesizing Google voices & rendering synced MP4... Please wait.");

        new Thread(() -> {
            File tempMp4 = null;
            try {
                int width = 720, height = 1280;
                if (ratioIdx == 1) { width = 1280; height = 720; }
                else if (ratioIdx == 2) { width = 1080; height = 1080; }
                else if (ratioIdx == 3) { width = 900; height = 1200; }

                int targetSampleRate = 44100;
                List<Short> mergedMonoPcm = new ArrayList<>();

                int leadSamples = (int) (targetSampleRate * 0.35);
                for (int i = 0; i < leadSamples; i++) mergedMonoPcm.add((short) 0);

                for (int i = 0; i < lines.size(); i++) {
                    LineSegment seg = lines.get(i);
                    VoiceOption chosenOpt = seg.isKhmer ? kmOpt : enOpt;
                    short[] linePcm = null;

                    // 1. Official Google Cloud TTS API
                    if (chosenOpt != null && chosenOpt.googleCloudName != null && !apiKey.isEmpty()) {
                        File mp3File = new File(getCacheDir(), "gcloud_" + i + "_" + System.nanoTime() + ".mp3");
                        try {
                            if (synthesizeWithGoogleCloudApi(seg.text, chosenOpt, styleIdx, apiKey, mp3File)) {
                                linePcm = decodeAudioFileToMono44k(mp3File, targetSampleRate);
                            }
                        } finally {
                            if (mp3File.exists()) mp3File.delete();
                        }
                    }

                    // 2. Device TTS Engine
                    if ((linePcm == null || linePcm.length == 0) && chosenOpt != null && chosenOpt.engineVoice != null && ttsReady) {
                        File wavFile = new File(getCacheDir(), "line_" + i + "_" + System.nanoTime() + ".wav");
                        try {
                            if (synthesizeToWav(seg.text, chosenOpt.engineVoice, styleIdx, wavFile)) {
                                WavData wd = readWav(wavFile);
                                linePcm = resampleToMono44k(wd, targetSampleRate);
                            }
                        } finally {
                            if (wavFile.exists()) wavFile.delete();
                        }
                    }

                    // 3. Free Cloud Neural TTS Fallback
                    if ((linePcm == null || linePcm.length == 0)) {
                        File mp3File = new File(getCacheDir(), "free_" + i + "_" + System.nanoTime() + ".mp3");
                        try {
                            String shortLang = seg.isKhmer ? "km" : "en";
                            if (downloadFreeCloudTtsMp3(seg.text, shortLang, mp3File)) {
                                linePcm = decodeAudioFileToMono44k(mp3File, targetSampleRate);
                            }
                        } finally {
                            if (mp3File.exists()) mp3File.delete();
                        }
                    }

                    if (linePcm == null || linePcm.length == 0) {
                        int fallbackSamples = (int) (targetSampleRate * Math.max(1.2, seg.text.length() * 0.08));
                        linePcm = new short[fallbackSamples];
                    }

                    long startSample = mergedMonoPcm.size();
                    for (short s : linePcm) mergedMonoPcm.add(s);
                    long endSample = mergedMonoPcm.size();

                    seg.startUs = (startSample * 1_000_000L) / targetSampleRate;
                    seg.endUs = (endSample * 1_000_000L) / targetSampleRate;

                    if (i < lines.size() - 1) {
                        int pauseSamples = (int) (targetSampleRate * 0.25);
                        for (int p = 0; p < pauseSamples; p++) mergedMonoPcm.add((short) 0);
                    }
                }

                int tailSamples = (int) (targetSampleRate * 0.5);
                for (int i = 0; i < tailSamples; i++) mergedMonoPcm.add((short) 0);

                Bitmap bgPhotoBitmap = null;
                if (bgUri != null) {
                    try (InputStream is = getContentResolver().openInputStream(bgUri)) {
                        bgPhotoBitmap = BitmapFactory.decodeStream(is);
                    } catch (Exception ignored) {}
                }

                tempMp4 = new File(getCacheDir(), "export_" + System.currentTimeMillis() + ".mp4");
                encodeSyncedVideoAndAudioToMp4(width, height, lines, bgCol, bgPhotoBitmap, mergedMonoPcm, targetSampleRate, tempMp4);

                if (bgPhotoBitmap != null) bgPhotoBitmap.recycle();

                String savedName = "EK_GoogleVoice_" + System.currentTimeMillis() + ".mp4";
                String savedLocation = saveMp4ToMovies(tempMp4, savedName);

                runOnUiThread(() -> {
                    isExporting = false;
                    exportBtn.setEnabled(true);
                    generateBtn.setEnabled(true);
                    renderLivePreviewHighlight(-1);
                    status.setText("MP4 Saved: " + savedLocation);
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("MP4 Export Complete")
                            .setMessage("Video with synced voice highlight saved to Gallery / Movies:\n" + savedLocation)
                            .setPositiveButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                e.printStackTrace();
                final String err = e.getMessage() != null ? e.getMessage() : e.toString();
                runOnUiThread(() -> {
                    isExporting = false;
                    exportBtn.setEnabled(true);
                    generateBtn.setEnabled(true);
                    status.setText("Export failed: " + err);
                });
            } finally {
                if (tempMp4 != null && tempMp4.exists()) tempMp4.delete();
            }
        }).start();
    }

    private short[] resampleToMono44k(WavData wd, int targetSampleRate) {
        int monoFrames = wd.pcm.length / wd.channels;
        if (monoFrames <= 0) return new short[0];
        double ratio = (double) wd.sampleRate / targetSampleRate;
        int outLen = (int) (monoFrames / ratio);
        short[] out = new short[outLen];
        for (int i = 0; i < outLen; i++) {
            int srcFrame = Math.min(monoFrames - 1, (int) (i * ratio));
            int sum = 0;
            for (int c = 0; c < wd.channels; c++) {
                sum += wd.pcm[srcFrame * wd.channels + c];
            }
            out[i] = (short) (sum / wd.channels);
        }
        return out;
    }

    private boolean synthesizeToWav(String text, Voice voice, int styleIdx, File outFile) {
        try {
            final CountDownLatch latch = new CountDownLatch(1);
            final boolean[] success = {false};
            final String uttId = "synth_" + System.nanoTime();

            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) {
                    if (uttId.equals(utteranceId)) {
                        success[0] = true;
                        latch.countDown();
                    }
                }
                @Override public void onError(String utteranceId) {
                    if (uttId.equals(utteranceId)) latch.countDown();
                }
            });

            applySpeakingStyle(styleIdx);
            tts.setVoice(voice);
            int res = tts.synthesizeToFile(text, new Bundle(), outFile, uttId);
            if (res != TextToSpeech.SUCCESS) return false;
            latch.await(25, TimeUnit.SECONDS);
            return success[0] && outFile.exists() && outFile.length() > 44;
        } catch (Exception e) {
            return false;
        }
    }

    private Bitmap renderFrameForTimestamp(int width, int height, List<LineSegment> lines, int activeLineIdx, int bgCol, Bitmap bgPhoto) {
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.drawColor(bgCol);

        if (bgPhoto != null) {
            float scale = Math.max((float) width / bgPhoto.getWidth(), (float) height / bgPhoto.getHeight());
            float newW = bgPhoto.getWidth() * scale;
            float newH = bgPhoto.getHeight() * scale;
            float left = (width - newW) / 2f;
            float top = (height - newH) / 2f;
            RectF dst = new RectF(left, top, left + newW, top + newH);
            canvas.drawBitmap(bgPhoto, null, dst, new Paint(Paint.FILTER_BITMAP_FLAG));

            Paint dim = new Paint();
            dim.setColor(Color.argb(110, 0, 0, 0));
            canvas.drawRect(0, 0, width, height, dim);
        }

        boolean darkBg = (bgPhoto != null || bgCol == Color.BLACK || bgCol == Color.rgb(20, 65, 130));
        int normalFg = darkBg ? Color.WHITE : Color.BLACK;
        int dimFg = darkBg ? Color.argb(155, 255, 255, 255) : Color.argb(145, 0, 0, 0);
        int highlightBoxColor = Color.rgb(255, 214, 10);
        int highlightTextColor = Color.BLACK;

        int padX = (int) (width * 0.08f);
        int textWidth = width - (padX * 2);
        float baseFontSize = Math.max(34f, width * 0.048f);
        if (lines.size() > 6) baseFontSize *= 0.82f;
        if (lines.size() > 10) baseFontSize *= 0.75f;

        List<StaticLayout> layouts = new ArrayList<>();
        float lineSpacing = baseFontSize * 0.48f;
        float totalHeight = 0f;

        for (int i = 0; i < lines.size(); i++) {
            LineSegment seg = lines.get(i);
            boolean isActive = (i == activeLineIdx);

            TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            tp.setTextSize(seg.isKhmer ? baseFontSize * 1.05f : baseFontSize);
            tp.setColor(isActive ? highlightTextColor : (activeLineIdx >= 0 ? dimFg : normalFg));
            if (isActive || !seg.isKhmer) {
                tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            }

            StaticLayout sl = StaticLayout.Builder.obtain(seg.text, 0, seg.text.length(), tp, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .build();
            layouts.add(sl);
            totalHeight += sl.getHeight();
            if (i < lines.size() - 1) totalHeight += lineSpacing;
        }

        float curY = Math.max(padX, (height - totalHeight) / 2f);
        Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        boxPaint.setColor(highlightBoxColor);

        for (int i = 0; i < lines.size(); i++) {
            StaticLayout sl = layouts.get(i);
            float lh = sl.getHeight();

            if (i == activeLineIdx) {
                float maxLineW = 0f;
                for (int l = 0; l < sl.getLineCount(); l++) {
                    maxLineW = Math.max(maxLineW, sl.getLineWidth(l));
                }
                float boxPadX = 24f;
                float boxPadY = 10f;
                float boxLeft = Math.max(padX - 12f, (width - maxLineW) / 2f - boxPadX);
                float boxRight = Math.min(width - padX + 12f, (width + maxLineW) / 2f + boxPadX);
                RectF pill = new RectF(boxLeft, curY - boxPadY, boxRight, curY + lh + boxPadY);
                canvas.drawRoundRect(pill, 18f, 18f, boxPaint);
            }

            canvas.save();
            canvas.translate(padX, curY);
            sl.draw(canvas);
            canvas.restore();

            curY += lh + lineSpacing;
        }
        return bmp;
    }

    private static class WavData {
        short[] pcm;
        int sampleRate;
        int channels;
    }

    private WavData readWav(File file) throws IOException {
        byte[] bytes = new byte[(int) file.length()];
        try (FileInputStream fis = new FileInputStream(file)) {
            int offset = 0;
            while (offset < bytes.length) {
                int r = fis.read(bytes, offset, bytes.length - offset);
                if (r < 0) break;
                offset += r;
            }
        }
        ByteBuffer bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        int channels = 1;
        int sampleRate = 22050;
        int dataOffset = 44;
        int dataSize = bytes.length - 44;

        int pos = 12;
        while (pos + 8 <= bytes.length) {
            int chunkId = bb.getInt(pos);
            int chunkSize = bb.getInt(pos + 4);
            if (chunkId == 0x20746d66) {
                channels = bb.getShort(pos + 10) & 0xFFFF;
                sampleRate = bb.getInt(pos + 12);
            } else if (chunkId == 0x61746164) {
                dataOffset = pos + 8;
                dataSize = Math.min(chunkSize, bytes.length - dataOffset);
                break;
            }
            pos += 8 + chunkSize + (chunkSize % 2);
        }

        int numSamples = Math.max(0, dataSize / 2);
        short[] samples = new short[numSamples];
        bb.position(dataOffset);
        for (int i = 0; i < numSamples; i++) {
            samples[i] = bb.getShort();
        }
        WavData wd = new WavData();
        wd.pcm = samples;
        wd.sampleRate = sampleRate > 0 ? sampleRate : 22050;
        wd.channels = channels > 0 ? channels : 1;
        return wd;
    }

    private void encodeSyncedVideoAndAudioToMp4(int width, int height, List<LineSegment> lines, int bgCol, Bitmap bgPhoto,
                                                 List<Short> mergedMonoPcm, int targetSampleRate, File outputMp4) throws Exception {
        long durationUs = (mergedMonoPcm.size() * 1_000_000L) / targetSampleRate;
        int fps = 15;
        int totalVideoFrames = Math.max(15, (int) ((durationUs * fps) / 1_000_000L));

        Map<Integer, Bitmap> stateBitmaps = new HashMap<>();
        stateBitmaps.put(-1, renderFrameForTimestamp(width, height, lines, -1, bgCol, bgPhoto));
        for (int i = 0; i < lines.size(); i++) {
            stateBitmaps.put(i, renderFrameForTimestamp(width, height, lines, i, bgCol, bgPhoto));
        }

        MediaMuxer muxer = new MediaMuxer(outputMp4.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

        MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000);
        videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

        MediaCodec videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        Surface inputSurface = videoEncoder.createInputSurface();
        videoEncoder.start();

        MediaFormat audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, targetSampleRate, 1);
        audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 96_000);
        audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);

        MediaCodec audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        audioEncoder.start();

        List<ByteBuffer> videoSamples = new ArrayList<>();
        List<MediaCodec.BufferInfo> videoInfos = new ArrayList<>();
        final MediaFormat[] finalVFormat = {null};
        MediaCodec.BufferInfo vInfo = new MediaCodec.BufferInfo();

        for (int frame = 0; frame < totalVideoFrames; frame++) {
            long framePtsUs = (frame * 1_000_000L) / fps;
            int activeIdx = -1;
            for (int i = 0; i < lines.size(); i++) {
                LineSegment seg = lines.get(i);
                if (framePtsUs >= seg.startUs && framePtsUs <= seg.endUs) {
                    activeIdx = i;
                    break;
                }
            }

            Bitmap frameBmp = stateBitmaps.get(activeIdx);
            Canvas c = inputSurface.lockCanvas(null);
            c.drawBitmap(frameBmp, 0, 0, null);
            inputSurface.unlockCanvasAndPost(c);

            drainEncoder(videoEncoder, vInfo, false, videoSamples, videoInfos, fmt -> finalVFormat[0] = fmt);
        }
        videoEncoder.signalEndOfInputStream();
        drainEncoder(videoEncoder, vInfo, true, videoSamples, videoInfos, fmt -> finalVFormat[0] = fmt);
        videoEncoder.stop();
        videoEncoder.release();
        inputSurface.release();

        for (Bitmap b : stateBitmaps.values()) {
            if (b != null && !b.isRecycled()) b.recycle();
        }

        List<ByteBuffer> audioSamples = new ArrayList<>();
        List<MediaCodec.BufferInfo> audioInfos = new ArrayList<>();
        final MediaFormat[] finalAFormat = {null};
        MediaCodec.BufferInfo aInfo = new MediaCodec.BufferInfo();

        int pcmCursor = 0;
        int totalPcm = mergedMonoPcm.size();
        boolean audioInputDone = false;
        boolean audioOutputDone = false;

        while (!audioOutputDone) {
            if (!audioInputDone) {
                int inIdx = audioEncoder.dequeueInputBuffer(10_000);
                if (inIdx >= 0) {
                    ByteBuffer inBuf = audioEncoder.getInputBuffer(inIdx);
                    inBuf.clear();
                    int maxSamples = inBuf.remaining() / 2;
                    int count = Math.min(maxSamples, totalPcm - pcmCursor);
                    long ptsUs = (pcmCursor * 1_000_000L) / targetSampleRate;
                    if (count > 0) {
                        for (int i = 0; i < count; i++) {
                            inBuf.putShort(mergedMonoPcm.get(pcmCursor + i));
                        }
                        pcmCursor += count;
                        audioEncoder.queueInputBuffer(inIdx, 0, count * 2, ptsUs, 0);
                    } else {
                        audioEncoder.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        audioInputDone = true;
                    }
                }
            }

            int outIdx = audioEncoder.dequeueOutputBuffer(aInfo, 10_000);
            if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                finalAFormat[0] = audioEncoder.getOutputFormat();
            } else if (outIdx >= 0) {
                ByteBuffer encoded = audioEncoder.getOutputBuffer(outIdx);
                if ((aInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && aInfo.size > 0) {
                    encoded.position(aInfo.offset);
                    encoded.limit(aInfo.offset + aInfo.size);
                    ByteBuffer copy = ByteBuffer.allocateDirect(aInfo.size);
                    copy.put(encoded);
                    copy.flip();

                    MediaCodec.BufferInfo infoCopy = new MediaCodec.BufferInfo();
                    infoCopy.set(0, aInfo.size, aInfo.presentationTimeUs, aInfo.flags);
                    audioSamples.add(copy);
                    audioInfos.add(infoCopy);
                }
                audioEncoder.releaseOutputBuffer(outIdx, false);
                if ((aInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    audioOutputDone = true;
                }
            }
        }
        audioEncoder.stop();
        audioEncoder.release();

        if (finalVFormat[0] == null) throw new RuntimeException("Video encoder did not produce output format.");
        int videoTrackIndex = muxer.addTrack(finalVFormat[0]);
        int audioTrackIndex = -1;
        if (finalAFormat[0] != null && !audioSamples.isEmpty()) {
            audioTrackIndex = muxer.addTrack(finalAFormat[0]);
        }
        muxer.start();

        for (int i = 0; i < videoSamples.size(); i++) {
            muxer.writeSampleData(videoTrackIndex, videoSamples.get(i), videoInfos.get(i));
        }
        if (audioTrackIndex >= 0) {
            for (int i = 0; i < audioSamples.size(); i++) {
                muxer.writeSampleData(audioTrackIndex, audioSamples.get(i), audioInfos.get(i));
            }
        }

        muxer.stop();
        muxer.release();
    }

    private interface FormatCallback {
        void onFormat(MediaFormat format);
    }

    private void drainEncoder(MediaCodec encoder, MediaCodec.BufferInfo info, boolean endOfStream,
                              List<ByteBuffer> outSamples, List<MediaCodec.BufferInfo> outInfos,
                              FormatCallback formatCallback) {
        while (true) {
            int outIdx = encoder.dequeueOutputBuffer(info, 10_000);
            if (outIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break;
            } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                formatCallback.onFormat(encoder.getOutputFormat());
            } else if (outIdx >= 0) {
                ByteBuffer encoded = encoder.getOutputBuffer(outIdx);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                    encoded.position(info.offset);
                    encoded.limit(info.offset + info.size);
                    ByteBuffer copy = ByteBuffer.allocateDirect(info.size);
                    copy.put(encoded);
                    copy.flip();

                    MediaCodec.BufferInfo infoCopy = new MediaCodec.BufferInfo();
                    long pts = outSamples.size() * (1_000_000L / 15L);
                    infoCopy.set(0, info.size, pts, info.flags);
                    outSamples.add(copy);
                    outInfos.add(infoCopy);
                }
                encoder.releaseOutputBuffer(outIdx, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }

    private String saveMp4ToMovies(File sourceMp4, String displayName) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/EnglishKhmerVideoMaker");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            ContentResolver resolver = getContentResolver();
            Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Could not create MediaStore video entry.");

            try (OutputStream os = resolver.openOutputStream(uri);
                 FileInputStream fis = new FileInputStream(sourceMp4)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) > 0) os.write(buf, 0, len);
            }

            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return "Movies/EnglishKhmerVideoMaker/" + displayName;
        } else {
            File moviesDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "EnglishKhmerVideoMaker");
            if (!moviesDir.exists()) moviesDir.mkdirs();
            File dest = new File(moviesDir, displayName);
            try (FileInputStream fis = new FileInputStream(sourceMp4);
                 FileOutputStream fos = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) > 0) fos.write(buf, 0, len);
            }
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(dest)));
            return dest.getAbsolutePath();
        }
    }

    private VoiceOption selectedOption(List<VoiceOption> options, Spinner spinner) {
        int pos = spinner.getSelectedItemPosition();
        return pos >= 0 && pos < options.size() ? options.get(pos) : null;
    }

    private void updatePreviewBackground() {
        previewCard.setBackgroundColor(backgroundColor);
        if (backgroundPhoto != null) {
            try {
                previewCard.setBackground(android.graphics.drawable.Drawable.createFromStream(
                        getContentResolver().openInputStream(backgroundPhoto), null));
            } catch (Exception ignored) {
                previewCard.setBackgroundColor(backgroundColor);
            }
        }
    }

    private void pasteInto(EditText target) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence value = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (value != null) target.setText(value);
        } else {
            status.setText("Clipboard is empty.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PHOTO && resultCode == RESULT_OK && data != null) {
            backgroundPhoto = data.getData();
            updatePreviewBackground();
            renderLivePreviewHighlight(-1);
            status.setText("Background photo selected.");
        }
    }

    private void section(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(17);
        t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(Color.rgb(35, 75, 145));
        t.setPadding(0, 20, 0, 8);
        root.addView(t);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private ArrayAdapter<String> adapter(List<String> values) {
        return new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
    }

    private ArrayAdapter<String> adapter(String[] values) {
        return new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
    }

    @Override
    protected void onDestroy() {
        stopAllAudio();
        if (tts != null) {
            tts.shutdown();
        }
        super.onDestroy();
    }
}
