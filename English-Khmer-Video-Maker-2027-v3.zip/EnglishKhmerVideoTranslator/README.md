# English Khmer Video Translator

Android prototype for composing paired English and Khmer text.

## Included in this prototype
- English and Khmer text input fields.
- Paste buttons for both fields and a Clear button.
- Choose an installed English TTS voice and an installed Khmer TTS voice independently.
- Speech playback preview (availability depends on voices installed on the Android device).
- Video aspect ratio selector: 9:16, 16:9, 1:1 and 3:4.
- Select a solid background color or a photo background.
- On-screen bilingual preview.

## Not yet implemented
- Rendering the preview into an MP4 file and exporting/saving it.
- Per-line multi-card/video sequence timeline.
- Guaranteed Khmer speech synthesis: Android devices may not have a Khmer TTS voice installed. The app lists voices available from the device speech engine.
- API key configuration from the earlier planned Gemini feature is not part of this UI revision.

The Export MP4 button intentionally explains that export is not yet enabled; it does not create a fake MP4.
