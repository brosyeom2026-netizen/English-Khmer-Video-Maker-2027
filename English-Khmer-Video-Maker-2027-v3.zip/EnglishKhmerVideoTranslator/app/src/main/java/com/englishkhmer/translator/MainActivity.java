package com.englishkhmer.translator;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_PHOTO = 72;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private Spinner englishVoice, khmerVoice, videoSize;
    private EditText englishText, khmerText;
    private LinearLayout previewCard;
    private TextView previewEnglish, previewKhmer, status;
    private int backgroundColor = Color.WHITE;
    private Uri backgroundPhoto;
    private final List<Voice> enVoices = new ArrayList<>();
    private final List<Voice> kmVoices = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        tts = new TextToSpeech(this, result -> {
            ttsReady = result == TextToSpeech.SUCCESS;
            if (ttsReady) runOnUiThread(this::loadVoices);
            else status.setText("Text-to-speech is unavailable on this phone.");
        });
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 36);
        root.setBackgroundColor(Color.rgb(244,247,252));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("English Khmer Video Translator");
        title.setTextSize(23); title.setTextColor(Color.rgb(25,65,145));
        title.setTypeface(null, 1); title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Create bilingual videos with English and Khmer voices");
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,8,0,20);
        root.addView(sub);

        section(root, "1. English");
        englishText = edit("Type English text — Hello");
        root.addView(englishText);
        englishVoice = new Spinner(this); root.addView(englishVoice);
        Button pasteEn = button("Paste English"); root.addView(pasteEn);
        pasteEn.setOnClickListener(v -> pasteInto(englishText));

        section(root, "2. Khmer");
        khmerText = edit("Type Khmer translation — សួស្តី");
        root.addView(khmerText);
        khmerVoice = new Spinner(this); root.addView(khmerVoice);
        Button pasteKm = button("Paste Khmer"); root.addView(pasteKm);
        pasteKm.setOnClickListener(v -> pasteInto(khmerText));

        section(root, "3. Video size");
        videoSize = new Spinner(this);
        videoSize.setAdapter(adapter(new String[]{"9:16 (Shorts / TikTok)","16:9 (YouTube)","1:1 (Square)","3:4 (Portrait)"}));
        root.addView(videoSize);

        section(root, "4. Background");
        LinearLayout colors = new LinearLayout(this);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        int[] palette = {Color.WHITE, Color.BLACK, Color.rgb(20,65,130), Color.rgb(255,220,80), Color.rgb(225,235,245)};
        String[] names = {"White","Black","Blue","Yellow","Light"};
        for (int i=0;i<palette.length;i++) {
            final int c = palette[i];
            Button b = button(names[i]);
            b.setOnClickListener(v -> { backgroundColor=c; backgroundPhoto=null; updatePreview(); });
            colors.addView(b, new LinearLayout.LayoutParams(0,-2,1));
        }
        root.addView(colors);
        Button photo = button("Add photo background"); root.addView(photo);
        photo.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*");
            startActivityForResult(Intent.createChooser(i,"Choose background photo"),PICK_PHOTO);
        });

        section(root, "5. Video preview");
        previewCard = new LinearLayout(this);
        previewCard.setOrientation(LinearLayout.VERTICAL);
        previewCard.setGravity(Gravity.CENTER);
        previewCard.setPadding(16,32,16,32);
        previewEnglish = new TextView(this); previewEnglish.setTextSize(24);
        previewEnglish.setTypeface(null,1); previewEnglish.setGravity(Gravity.CENTER);
        previewKhmer = new TextView(this); previewKhmer.setTextSize(25);
        previewKhmer.setGravity(Gravity.CENTER); previewKhmer.setPadding(0,18,0,0);
        previewCard.addView(previewEnglish); previewCard.addView(previewKhmer);
        root.addView(previewCard);
        updatePreview();

        Button generate = button("Generate / Preview voices"); root.addView(generate);
        generate.setOnClickListener(v -> generatePreview());

        Button export = button("Export MP4"); root.addView(export);
        export.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("MP4 export")
            .setMessage("The current project includes bilingual text preview, voice selection and speech playback. MP4 video rendering/export is the next implementation stage and is not yet enabled in this prototype.")
            .setPositiveButton("OK",null).show());

        Button clear = button("Clear"); root.addView(clear);
        clear.setOnClickListener(v -> {
            englishText.setText(""); khmerText.setText("");
            previewEnglish.setText(""); previewKhmer.setText("");
            backgroundPhoto=null; backgroundColor=Color.WHITE; updatePreview();
            status.setText("Cleared.");
        });

        status = new TextView(this);
        status.setText("Ready. Choose voices and enter your English and Khmer text.");
        status.setPadding(0,18,0,0); root.addView(status);
        setContentView(scroll);
    }

    private void loadVoices() {
        enVoices.clear(); kmVoices.clear();
        Set<Voice> all = tts.getVoices();
        if (all != null) for (Voice voice : all) {
            String lang = voice.getLocale().getLanguage();
            if ("en".equals(lang)) enVoices.add(voice);
            if ("km".equals(lang)) kmVoices.add(voice);
        }
        englishVoice.setAdapter(adapter(voiceNames(enVoices,"English voice")));
        khmerVoice.setAdapter(adapter(voiceNames(kmVoices,"Khmer voice")));
        if (kmVoices.isEmpty()) status.setText("No Khmer TTS voice is installed. Install a Khmer-capable speech engine/voice in Android settings.");
    }

    private List<String> voiceNames(List<Voice> voices, String fallback) {
        List<String> names = new ArrayList<>();
        for (Voice v : voices) names.add(v.getName()+" ("+v.getLocale().toLanguageTag()+")");
        if (names.isEmpty()) names.add("No "+fallback+" available on this device");
        return names;
    }

    private void generatePreview() {
        String en = englishText.getText().toString().trim();
        String km = khmerText.getText().toString().trim();
        if (en.isEmpty() && km.isEmpty()) { status.setText("Enter English and/or Khmer text first."); return; }
        previewEnglish.setText(en); previewKhmer.setText(km); updatePreview();
        if (!ttsReady) { status.setText("Speech engine is still loading."); return; }
        Voice ev = selected(enVoices, englishVoice);
        Voice kv = selected(kmVoices, khmerVoice);
        if (!en.isEmpty() && ev != null) {
            tts.setVoice(ev);
            tts.speak(en, TextToSpeech.QUEUE_FLUSH, null, "english_preview");
        }
        if (!km.isEmpty() && kv != null) {
            tts.setVoice(kv);
            tts.speak(km, TextToSpeech.QUEUE_ADD, null, "khmer_preview");
        } else if (!km.isEmpty()) {
            status.setText("English preview started. No Khmer voice is available on this device; Khmer text remains visible.");
            return;
        }
        status.setText("Preview displayed. Speech playback queued.");
    }

    private Voice selected(List<Voice> voices, Spinner spinner) {
        int pos = spinner.getSelectedItemPosition();
        return pos >= 0 && pos < voices.size() ? voices.get(pos) : null;
    }

    private void updatePreview() {
        previewCard.setBackgroundColor(backgroundColor);
        int fg = (backgroundColor == Color.BLACK || backgroundColor == Color.rgb(20,65,130)) ? Color.WHITE : Color.BLACK;
        previewEnglish.setTextColor(fg); previewKhmer.setTextColor(fg);
        if (backgroundPhoto != null) {
            try { previewCard.setBackground(android.graphics.drawable.Drawable.createFromStream(getContentResolver().openInputStream(backgroundPhoto),null)); }
            catch(Exception ignored) { previewCard.setBackgroundColor(backgroundColor); }
        }
    }

    private void pasteInto(EditText target) {
        ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount()>0) {
            CharSequence value = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (value != null) target.setText(value);
        } else status.setText("Clipboard is empty.");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==PICK_PHOTO && resultCode==RESULT_OK && data!=null) {
            backgroundPhoto=data.getData(); updatePreview(); status.setText("Background photo selected.");
        }
    }

    private void section(LinearLayout root,String text) {
        TextView t=new TextView(this); t.setText(text); t.setTextSize(17);
        t.setTypeface(null,1); t.setTextColor(Color.rgb(35,75,145)); t.setPadding(0,20,0,8); root.addView(t);
    }
    private EditText edit(String hint) {
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(17);
        e.setMinLines(2); e.setGravity(Gravity.TOP); return e;
    }
    private Button button(String text) {
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); return b;
    }
    private ArrayAdapter<String> adapter(List<String> values) {
        return new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
    }
    private ArrayAdapter<String> adapter(String[] values) {
        return new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
    }
    @Override protected void onDestroy() {
        if (tts!=null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
