package com.englishkhmer.translator;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Gravity;
import android.view.Surface;
import android.view.View;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int PICK_PHOTO = 72;
    private static final String PREFS_NAME = "ek_video_maker_prefs";
    private static final String KEY_GEMINI_API = "gemini_api_key";
    private static final String KEY_EN_VOICE = "selected_en_voice_label";
    private static final String KEY_KM_VOICE = "selected_km_voice_label";
    private static final String KEY_STYLE_IDX = "selected_style_idx";
    private static final String KEY_RATIO_IDX = "selected_ratio_idx";

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private EditText apiKeyInput, combinedText;
    private TextView apiStatusBadge, previewStatusBadge, status;
    private ImageView previewImageView;
    private Spinner englishVoice, khmerVoice, videoSize, voiceStyle;
    private Button generateBtn, exportBtn, clearBtn, pasteBtn, activateKeyBtn;
    private int backgroundColor = Color.WHITE;
    private Uri backgroundPhoto;
    private Bitmap cachedBgPhoto;
    private final List<VoiceOption> enVoiceOptions = new ArrayList<>();
    private final List<VoiceOption> kmVoiceOptions = new ArrayList<>();
    private volatile boolean isWorking = false;
    private volatile boolean stopRequested = false;
    private MediaPlayer activeOnlinePlayer;
    private final List<String> discoveredModels = new ArrayList<>();
    private boolean isBindingSpinners = false;

    // Cached Preview Package: holds exact generated voices + rendered frames ready for instant MP4 export
    private static class PreparedPreview {
        int width;
        int height;
        List<LineSegment> lines;
        List<Short> mergedMonoPcm;
        int sampleRate;
        Map<Integer, Bitmap> stateFrames; // -1 = idle, 0..N-1 = highlighted line i
        String summary;

        void recycleBitmaps() {
            if (stateFrames != null) {
                for (Bitmap b : stateFrames.values()) {
                    if (b != null && !b.isRecycled()) b.recycle();
                }
                stateFrames.clear();
            }
        }
    }

    private PreparedPreview readyPreview = null;

    private static class VoiceOption {
        final String label;
        final Voice engineVoice;
        final String geminiVoiceName;

        VoiceOption(String label, Voice engineVoice, String geminiVoiceName) {
            this.label = label;
            this.engineVoice = engineVoice;
            this.geminiVoiceName = geminiVoiceName;
        }
    }

    private static class LineSegment {
        final String text;
        final boolean isKhmer;
        long startUs;
        long endUs;

        LineSegment(String text, boolean isKhmer) {
            this.text = text;
            this.isKhmer = isKhmer;
        }
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        cleanAllTempFiles();
        buildScreen();
        loadSavedSettings();
        tts = new TextToSpeech(this, result -> {
            ttsReady = result == TextToSpeech.SUCCESS;
            runOnUiThread(this::loadVoices);
        }, "com.google.android.tts");
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 36);
        root.setBackgroundColor(Color.rgb(244, 247, 252));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("English Khmer Video Maker");
        title.setTextSize(23);
        title.setTextColor(Color.rgb(25, 65, 145));
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("1. Generate Voices + Photo Preview  →  2. Export MP4");
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 6, 0, 14);
        root.addView(sub);

        // --- SECTION 0: GEMINI API KEY ACTIVE BOX ---
        section(root, "Gemini API Key (Active Box)");
        LinearLayout apiBox = new LinearLayout(this);
        apiBox.setOrientation(LinearLayout.VERTICAL);
        apiBox.setBackgroundColor(Color.WHITE);
        apiBox.setPadding(20, 18, 20, 18);

        apiStatusBadge = new TextView(this);
        apiStatusBadge.setText("● Status: Inactive (Paste Gemini API Key)");
        apiStatusBadge.setTextColor(Color.rgb(180, 95, 6));
        apiStatusBadge.setTypeface(null, Typeface.BOLD);
        apiStatusBadge.setTextSize(14);
        apiStatusBadge.setPadding(0, 0, 0, 10);
        apiBox.addView(apiStatusBadge);

        apiKeyInput = new EditText(this);
        apiKeyInput.setHint("Paste Gemini API Key (AIzaSy...)");
        apiKeyInput.setTextSize(15);
        apiKeyInput.setSingleLine(true);
        apiKeyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        apiKeyInput.setBackgroundColor(Color.rgb(245, 248, 253));
        apiKeyInput.setPadding(16, 14, 16, 14);
        apiBox.addView(apiKeyInput);

        LinearLayout apiBtnRow = new LinearLayout(this);
        apiBtnRow.setOrientation(LinearLayout.HORIZONTAL);
        apiBtnRow.setPadding(0, 10, 0, 0);

        Button pasteKeyBtn = button("Paste Key");
        pasteKeyBtn.setOnClickListener(v -> pasteInto(apiKeyInput));
        apiBtnRow.addView(pasteKeyBtn, new LinearLayout.LayoutParams(0, -2, 1));

        activateKeyBtn = button("Save & Activate");
        activateKeyBtn.setBackgroundColor(Color.rgb(35, 87, 198));
        activateKeyBtn.setTextColor(Color.WHITE);
        activateKeyBtn.setOnClickListener(v -> verifyAndActivateApiKey());
        apiBtnRow.addView(activateKeyBtn, new LinearLayout.LayoutParams(0, -2, 1.3f));

        Button clearKeyBtn = button("Clear");
        clearKeyBtn.setOnClickListener(v -> {
            apiKeyInput.setText("");
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().remove(KEY_GEMINI_API).apply();
            updateApiBadge(false, "Inactive (Cleared)");
            invalidatePreparedPreview();
            loadVoices();
            status.setText("Gemini API key cleared.");
        });
        apiBtnRow.addView(clearKeyBtn, new LinearLayout.LayoutParams(0, -2, 0.9f));

        apiBox.addView(apiBtnRow);
        root.addView(apiBox);

        // --- SECTION 1: COMBINED ENGLISH & KHMER TEXT ---
        section(root, "1. English & Khmer Text");
        combinedText = new EditText(this);
        combinedText.setHint("Hello\nសួរស្ដី\nHow are you?\nតើអ្នកសុខសប្បាយទេ?");
        combinedText.setTextSize(17);
        combinedText.setMinLines(5);
        combinedText.setMaxLines(12);
        combinedText.setGravity(Gravity.TOP | Gravity.START);
        combinedText.setBackgroundColor(Color.WHITE);
        combinedText.setPadding(20, 18, 20, 18);
        combinedText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                if (!isWorking) {
                    invalidatePreparedPreview();
                    refreshExactPreview(-1);
                }
            }
        });
        root.addView(combinedText);

        LinearLayout textActions = new LinearLayout(this);
        textActions.setOrientation(LinearLayout.HORIZONTAL);
        textActions.setPadding(0, 8, 0, 4);

        pasteBtn = button("Paste");
        pasteBtn.setOnClickListener(v -> {
            if (isWorking) return;
            pasteInto(combinedText);
            invalidatePreparedPreview();
            refreshExactPreview(-1);
        });
        textActions.addView(pasteBtn, new LinearLayout.LayoutParams(0, -2, 1));

        clearBtn = button("Clear");
        clearBtn.setOnClickListener(v -> {
            if (isWorking) return;
            stopAllAudio();
            invalidatePreparedPreview();
            combinedText.setText("");
            backgroundPhoto = null;
            if (cachedBgPhoto != null && !cachedBgPhoto.isRecycled()) {
                cachedBgPhoto.recycle();
            }
            cachedBgPhoto = null;
            backgroundColor = Color.WHITE;
            refreshExactPreview(-1);
            status.setText("Cleared.");
        });
        textActions.addView(clearBtn, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(textActions);

        // --- SECTION 2: VOICES & STYLE ---
        section(root, "2. Voices & Emotion");
        TextView enLabel = new TextView(this);
        enLabel.setText("English Voice:");
        enLabel.setTextSize(14);
        root.addView(enLabel);
        englishVoice = new Spinner(this);
        englishVoice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (!isBindingSpinners && pos >= 0 && pos < enVoiceOptions.size()) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                            .edit().putString(KEY_EN_VOICE, enVoiceOptions.get(pos).label).apply();
                    invalidatePreparedPreview();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        root.addView(englishVoice);

        TextView kmLabel = new TextView(this);
        kmLabel.setText("Khmer Voice:");
        kmLabel.setTextSize(14);
        kmLabel.setPadding(0, 8, 0, 0);
        root.addView(kmLabel);
        khmerVoice = new Spinner(this);
        khmerVoice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (!isBindingSpinners && pos >= 0 && pos < kmVoiceOptions.size()) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                            .edit().putString(KEY_KM_VOICE, kmVoiceOptions.get(pos).label).apply();
                    invalidatePreparedPreview();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        root.addView(khmerVoice);

        TextView styleLabel = new TextView(this);
        styleLabel.setText("Voice Emotion / Style:");
        styleLabel.setTextSize(14);
        styleLabel.setPadding(0, 8, 0, 0);
        root.addView(styleLabel);
        voiceStyle = new Spinner(this);
        voiceStyle.setAdapter(adapter(new String[]{
                "Natural Conversational (Warm & Clear)",
                "Slow & Clear Teacher (Educational)",
                "Calm Storyteller (Deep & Expressive)",
                "Energetic & Cheerful (Shorts / TikTok)"
        }));
        voiceStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (!isBindingSpinners) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putInt(KEY_STYLE_IDX, pos).apply();
                    invalidatePreparedPreview();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        root.addView(voiceStyle);

        // --- SECTION 3: VIDEO SIZE ---
        section(root, "3. Video Size");
        videoSize = new Spinner(this);
        videoSize.setAdapter(adapter(new String[]{
                "9:16 (Shorts / TikTok)",
                "16:9 (YouTube)",
                "1:1 (Square)",
                "3:4 (Portrait)"
        }));
        videoSize.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (!isBindingSpinners) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putInt(KEY_RATIO_IDX, pos).apply();
                    invalidatePreparedPreview();
                }
                refreshExactPreview(-1);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        root.addView(videoSize);

        // --- SECTION 4: BACKGROUND ---
        section(root, "4. Background / Photo");
        LinearLayout colors = new LinearLayout(this);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        int[] palette = {Color.WHITE, Color.BLACK, Color.rgb(20, 65, 130), Color.rgb(255, 220, 80), Color.rgb(225, 235, 245)};
        String[] names = {"White", "Black", "Blue", "Yellow", "Light"};
        for (int i = 0; i < palette.length; i++) {
            final int c = palette[i];
            Button b = button(names[i]);
            b.setOnClickListener(v -> {
                if (isWorking) return;
                backgroundColor = c;
                backgroundPhoto = null;
                if (cachedBgPhoto != null && !cachedBgPhoto.isRecycled()) {
                    cachedBgPhoto.recycle();
                }
                cachedBgPhoto = null;
                invalidatePreparedPreview();
                refreshExactPreview(-1);
            });
            colors.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(colors);

        Button photo = button("Add photo background");
        root.addView(photo);
        photo.setOnClickListener(v -> {
            if (isWorking) return;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Choose background photo"), PICK_PHOTO);
        });

        // --- SECTION 5: PREVIEW (VOICES + PHOTO) & EXPORT ---
        section(root, "5. Preview (Voices + Photo) & Export MP4");

        previewStatusBadge = new TextView(this);
        previewStatusBadge.setText("● Preview Status: Not generated yet — Tap 'Generate Preview' first");
        previewStatusBadge.setTextColor(Color.rgb(180, 95, 6));
        previewStatusBadge.setTypeface(null, Typeface.BOLD);
        previewStatusBadge.setTextSize(13);
        previewStatusBadge.setPadding(0, 0, 0, 8);
        root.addView(previewStatusBadge);

        LinearLayout previewWrapper = new LinearLayout(this);
        previewWrapper.setOrientation(LinearLayout.VERTICAL);
        previewWrapper.setGravity(Gravity.CENTER);
        previewWrapper.setBackgroundColor(Color.rgb(215, 222, 235));
        previewWrapper.setPadding(16, 16, 16, 16);

        previewImageView = new ImageView(this);
        previewImageView.setAdjustViewBounds(true);
        previewImageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewWrapper.addView(previewImageView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 760));
        root.addView(previewWrapper);

        generateBtn = button("1. Generate Preview (Voices + Photo)");
        generateBtn.setBackgroundColor(Color.rgb(35, 87, 198));
        generateBtn.setTextColor(Color.WHITE);
        root.addView(generateBtn);
        generateBtn.setOnClickListener(v -> generateAndPlayPreview());

        exportBtn = button("2. Export MP4 from Preview");
        exportBtn.setEnabled(false);
        exportBtn.setBackgroundColor(Color.rgb(160, 175, 190));
        exportBtn.setTextColor(Color.WHITE);
        root.addView(exportBtn);
        exportBtn.setOnClickListener(v -> exportMp4FromPreparedPreview());

        status = new TextView(this);
        status.setText("Step 1: Tap 'Generate Preview (Voices + Photo)' to prepare & hear your video.");
        status.setPadding(0, 18, 0, 0);
        root.addView(status);
        setContentView(scroll);

        refreshExactPreview(-1);
    }

    private void invalidatePreparedPreview() {
        if (readyPreview != null) {
            readyPreview.recycleBitmaps();
            readyPreview = null;
        }
        if (previewStatusBadge != null) {
            previewStatusBadge.setText("● Preview Status: Needs Generation — Tap '1. Generate Preview' first");
            previewStatusBadge.setTextColor(Color.rgb(180, 95, 6));
        }
        if (exportBtn != null) {
            exportBtn.setEnabled(false);
            exportBtn.setBackgroundColor(Color.rgb(160, 175, 190));
        }
    }

    private void markPreviewReady(PreparedPreview prep) {
        if (readyPreview != null && readyPreview != prep) {
            readyPreview.recycleBitmaps();
        }
        readyPreview = prep;
        previewStatusBadge.setText("● Preview READY: Voices + Photo rendered (" + prep.width + "x" + prep.height + ") — Ready to Export MP4!");
        previewStatusBadge.setTextColor(Color.rgb(22, 145, 75));
        exportBtn.setEnabled(true);
        exportBtn.setBackgroundColor(Color.rgb(22, 160, 133));
    }

    private void loadSavedSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedKey = prefs.getString(KEY_GEMINI_API, "");
        if (savedKey != null && !savedKey.trim().isEmpty()) {
            apiKeyInput.setText(savedKey.trim());
            updateApiBadge(true, "ACTIVE (Gemini AI Voices Ready)");
        }
        isBindingSpinners = true;
        int savedStyle = prefs.getInt(KEY_STYLE_IDX, 0);
        if (savedStyle >= 0 && savedStyle < voiceStyle.getCount()) voiceStyle.setSelection(savedStyle);
        int savedRatio = prefs.getInt(KEY_RATIO_IDX, 0);
        if (savedRatio >= 0 && savedRatio < videoSize.getCount()) videoSize.setSelection(savedRatio);
        isBindingSpinners = false;
    }

    private void updateApiBadge(boolean active, String msg) {
        if (active) {
            apiStatusBadge.setText("● Status: " + msg);
            apiStatusBadge.setTextColor(Color.rgb(22, 145, 75));
        } else {
            apiStatusBadge.setText("● Status: " + msg);
            apiStatusBadge.setTextColor(Color.rgb(185, 70, 30));
        }
    }

    private String getActiveApiKey() {
        if (apiKeyInput == null) return "";
        return apiKeyInput.getText().toString().trim();
    }

    private void verifyAndActivateApiKey() {
        final String key = getActiveApiKey();
        if (key.isEmpty()) {
            updateApiBadge(false, "Please paste your Gemini API key first");
            return;
        }
        activateKeyBtn.setEnabled(false);
        updateApiBadge(false, "Verifying Gemini API Key...");

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models?key=" + URLEncoder.encode(key, "UTF-8"));
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(12000);
                int code = conn.getResponseCode();

                if (code == 200) {
                    String modelsResp = readStream(conn.getInputStream());
                    parseAvailableFlashModels(modelsResp);
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(KEY_GEMINI_API, key).apply();
                    runOnUiThread(() -> {
                        activateKeyBtn.setEnabled(true);
                        updateApiBadge(true, "ACTIVE (Gemini API Key Verified)");
                        invalidatePreparedPreview();
                        loadVoices();
                        status.setText("Gemini API Key activated!");
                    });
                } else {
                    String errDetail = readStream(conn.getErrorStream());
                    String shortMsg = "Invalid Gemini API Key (HTTP " + code + ")";
                    try {
                        JSONObject errObj = new JSONObject(errDetail);
                        if (errObj.has("error")) {
                            shortMsg = errObj.getJSONObject("error").optString("message", shortMsg);
                        }
                    } catch (Exception ignored) {}
                    final String finalErr = shortMsg;
                    runOnUiThread(() -> {
                        activateKeyBtn.setEnabled(true);
                        updateApiBadge(false, "Error: " + finalErr);
                        status.setText("Gemini Key error: " + finalErr);
                    });
                }
            } catch (Exception e) {
                final String msg = e.getMessage() != null ? e.getMessage() : "Network error";
                runOnUiThread(() -> {
                    activateKeyBtn.setEnabled(true);
                    updateApiBadge(false, "Connection failed: " + msg);
                });
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void parseAvailableFlashModels(String jsonStr) {
        try {
            JSONObject obj = new JSONObject(jsonStr);
            JSONArray arr = obj.optJSONArray("models");
            if (arr == null) return;
            List<String> found = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject m = arr.getJSONObject(i);
                String name = m.optString("name", "");
                if (name.startsWith("models/")) name = name.substring(7);
                JSONArray methods = m.optJSONArray("supportedGenerationMethods");
                boolean supportsGen = false;
                if (methods != null) {
                    for (int j = 0; j < methods.length(); j++) {
                        if ("generateContent".equals(methods.getString(j))) {
                            supportsGen = true;
                            break;
                        }
                    }
                }
                if (supportsGen && (name.contains("tts") || name.contains("flash"))) {
                    if (name.contains("tts")) found.add(0, name);
                    else found.add(name);
                }
            }
            if (!found.isEmpty()) {
                synchronized (discoveredModels) {
                    discoveredModels.clear();
                    discoveredModels.addAll(found);
                }
            }
        } catch (Exception ignored) {}
    }

    private void ensureModelsDiscovered(String apiKey) {
        synchronized (discoveredModels) {
            if (!discoveredModels.isEmpty()) return;
        }
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models?key=" + URLEncoder.encode(apiKey, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            if (conn.getResponseCode() == 200) {
                parseAvailableFlashModels(readStream(conn.getInputStream()));
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String readStream(InputStream is) {
        if (is == null) return "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void applySpeakingStyle(int styleIdx) {
        if (!ttsReady || tts == null) return;
        if (styleIdx == 1) {
            tts.setSpeechRate(0.84f);
            tts.setPitch(1.00f);
        } else if (styleIdx == 2) {
            tts.setSpeechRate(0.92f);
            tts.setPitch(0.93f);
        } else if (styleIdx == 3) {
            tts.setSpeechRate(1.05f);
            tts.setPitch(1.05f);
        } else {
            tts.setSpeechRate(0.96f);
            tts.setPitch(0.98f);
        }
    }

    private void loadVoices() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String previouslySelectedEn = (englishVoice.getSelectedItem() != null)
                ? englishVoice.getSelectedItem().toString()
                : prefs.getString(KEY_EN_VOICE, "");
        String previouslySelectedKm = (khmerVoice.getSelectedItem() != null)
                ? khmerVoice.getSelectedItem().toString()
                : prefs.getString(KEY_KM_VOICE, "");

        enVoiceOptions.clear();
        kmVoiceOptions.clear();

        boolean hasKey = !getActiveApiKey().isEmpty();

        if (hasKey) {
            enVoiceOptions.add(new VoiceOption("★ Gemini AI: Aoede — Female", null, "Aoede"));
            enVoiceOptions.add(new VoiceOption("★ Gemini AI: Puck — Male", null, "Puck"));
            enVoiceOptions.add(new VoiceOption("★ Gemini AI: Kore — Female", null, "Kore"));
            enVoiceOptions.add(new VoiceOption("★ Gemini AI: Fenrir — Male", null, "Fenrir"));
            enVoiceOptions.add(new VoiceOption("★ Gemini AI: Zephyr — Female", null, "Zephyr"));
            enVoiceOptions.add(new VoiceOption("★ Gemini AI: Charon — Male", null, "Charon"));
            enVoiceOptions.add(new VoiceOption("★ Gemini AI: Leda — Female", null, "Leda"));
            enVoiceOptions.add(new VoiceOption("★ Gemini AI: Orus — Male", null, "Orus"));

            kmVoiceOptions.add(new VoiceOption("★ Gemini AI: Aoede — Khmer Female", null, "Aoede"));
            kmVoiceOptions.add(new VoiceOption("★ Gemini AI: Puck — Khmer Male", null, "Puck"));
            kmVoiceOptions.add(new VoiceOption("★ Gemini AI: Kore — Khmer Female", null, "Kore"));
            kmVoiceOptions.add(new VoiceOption("★ Gemini AI: Fenrir — Khmer Male", null, "Fenrir"));
            kmVoiceOptions.add(new VoiceOption("★ Gemini AI: Zephyr — Khmer Female", null, "Zephyr"));
            kmVoiceOptions.add(new VoiceOption("★ Gemini AI: Charon — Khmer Male", null, "Charon"));
        }

        enVoiceOptions.add(new VoiceOption("Free Cloud Neural Voice (English)", null, null));
        kmVoiceOptions.add(new VoiceOption("Free Cloud Neural Voice (Khmer • ភាសាខ្មែរ)", null, null));

        if (ttsReady && tts != null) {
            Set<Voice> all = tts.getVoices();
            if (all != null) {
                for (Voice v : all) {
                    String lang = v.getLocale().getLanguage();
                    if ("en".equals(lang)) {
                        enVoiceOptions.add(new VoiceOption("Device Voice: " + v.getName() + " (" + v.getLocale().toLanguageTag() + ")", v, null));
                    } else if ("km".equals(lang)) {
                        kmVoiceOptions.add(new VoiceOption("Device Voice: " + v.getName() + " (" + v.getLocale().toLanguageTag() + ")", v, null));
                    }
                }
            }
        }

        isBindingSpinners = true;
        try {
            List<String> enLabels = new ArrayList<>();
            int enMatchIdx = 0;
            for (int i = 0; i < enVoiceOptions.size(); i++) {
                String lbl = enVoiceOptions.get(i).label;
                enLabels.add(lbl);
                if (lbl.equals(previouslySelectedEn)) enMatchIdx = i;
            }
            englishVoice.setAdapter(adapter(enLabels));
            if (enMatchIdx < enLabels.size()) englishVoice.setSelection(enMatchIdx);

            List<String> kmLabels = new ArrayList<>();
            int kmMatchIdx = 0;
            for (int i = 0; i < kmVoiceOptions.size(); i++) {
                String lbl = kmVoiceOptions.get(i).label;
                kmLabels.add(lbl);
                if (lbl.equals(previouslySelectedKm)) kmMatchIdx = i;
            }
            khmerVoice.setAdapter(adapter(kmLabels));
            if (kmMatchIdx < kmLabels.size()) khmerVoice.setSelection(kmMatchIdx);
        } finally {
            isBindingSpinners = false;
        }
    }

    private boolean containsKhmer(String text) {
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if ((ch >= '\u1780' && ch <= '\u17FF') || (ch >= '\u19E0' && ch <= '\u19FF')) {
                return true;
            }
        }
        return false;
    }

    private List<LineSegment> parseLines(String raw) {
        List<LineSegment> list = new ArrayList<>();
        if (raw == null) return list;
        String[] split = raw.split("\r?\n");
        for (String s : split) {
            String trimmed = s.trim();
            if (!trimmed.isEmpty()) {
                list.add(new LineSegment(trimmed, containsKhmer(trimmed)));
            }
        }
        return list;
    }

    private int[] getVideoDimensions(int ratioIdx) {
        if (ratioIdx == 1) return new int[]{1280, 720};  // 16:9
        if (ratioIdx == 2) return new int[]{1080, 1080}; // 1:1
        if (ratioIdx == 3) return new int[]{900, 1200};  // 3:4
        return new int[]{720, 1280};                     // 9:16
    }

    private void refreshExactPreview(int activeLineIdx) {
        if (previewImageView == null) return;
        if (readyPreview != null && readyPreview.stateFrames != null && readyPreview.stateFrames.containsKey(activeLineIdx)) {
            Bitmap b = readyPreview.stateFrames.get(activeLineIdx);
            if (b != null && !b.isRecycled()) {
                previewImageView.setImageBitmap(b);
                return;
            }
        }
        int ratioIdx = videoSize != null ? videoSize.getSelectedItemPosition() : 0;
        int[] dims = getVideoDimensions(ratioIdx);
        List<LineSegment> lines = parseLines(combinedText != null ? combinedText.getText().toString() : "");
        Bitmap frame = renderFrameForTimestamp(dims[0], dims[1], lines, activeLineIdx, backgroundColor, cachedBgPhoto);
        previewImageView.setImageBitmap(frame);
    }

    private void stopAllAudio() {
        stopRequested = true;
        if (tts != null) tts.stop();
        if (activeOnlinePlayer != null) {
            try {
                if (activeOnlinePlayer.isPlaying()) activeOnlinePlayer.stop();
                activeOnlinePlayer.release();
            } catch (Exception ignored) {}
            activeOnlinePlayer = null;
        }
    }

    /**
     * Step 1: Generates the complete Voices + Photo preview package (exact PCM audio + exact rendered video frames),
     * plays it back with synced text highlights, and keeps it cached in `readyPreview` so Step 2 (Export MP4)
     * encodes directly from those exact generated voices + photo frames!
     */
    private void generateAndPlayPreview() {
        if (isWorking) return;
        final List<LineSegment> lines = parseLines(combinedText.getText().toString());
        if (lines.isEmpty()) {
            status.setText("Enter or paste English and Khmer text first.");
            return;
        }
        stopAllAudio();
        stopRequested = false;
        invalidatePreparedPreview();

        final int ratioIdx = videoSize.getSelectedItemPosition();
        final VoiceOption enOpt = selectedOption(enVoiceOptions, englishVoice);
        final VoiceOption kmOpt = selectedOption(kmVoiceOptions, khmerVoice);
        final int styleIdx = voiceStyle.getSelectedItemPosition();
        final int bgCol = backgroundColor;
        final Bitmap bgPhotoCopy = (cachedBgPhoto != null && !cachedBgPhoto.isRecycled())
                ? cachedBgPhoto.copy(Bitmap.Config.ARGB_8888, false) : null;
        final String apiKey = getActiveApiKey();

        isWorking = true;
        generateBtn.setEnabled(false);
        exportBtn.setEnabled(false);
        previewStatusBadge.setText("● Generating Preview (Voices + Photo)...");
        previewStatusBadge.setTextColor(Color.rgb(35, 87, 198));
        status.setText("Synthesizing voices & rendering photo frames...");

        new Thread(() -> {
            File previewWavFile = null;
            try {
                int[] dims = getVideoDimensions(ratioIdx);
                int width = dims[0];
                int height = dims[1];
                int targetSampleRate = 44100;

                List<Short> mergedMonoPcm = new ArrayList<>();
                int leadSamples = (int) (targetSampleRate * 0.35);
                for (int i = 0; i < leadSamples; i++) mergedMonoPcm.add((short) 0);

                for (int i = 0; i < lines.size(); i++) {
                    if (stopRequested) throw new RuntimeException("Cancelled");
                    final int stepNum = i + 1;
                    final int totalSteps = lines.size();
                    runOnUiThread(() -> status.setText("Generating voice " + stepNum + " of " + totalSteps + "..."));

                    LineSegment seg = lines.get(i);
                    VoiceOption chosenOpt = seg.isKhmer ? kmOpt : enOpt;
                    short[] linePcm = null;

                    if (chosenOpt != null && chosenOpt.geminiVoiceName != null) {
                        if (apiKey.isEmpty()) {
                            throw new RuntimeException("Gemini API Key is required for " + chosenOpt.label);
                        }
                        File geminiWav = new File(getCacheDir(), "prev_gem_" + i + "_" + System.nanoTime() + ".wav");
                        try {
                            String[] errOut = new String[1];
                            if (synthesizeWithGeminiApi(seg.text, seg.isKhmer, chosenOpt.geminiVoiceName, styleIdx, apiKey, geminiWav, errOut)) {
                                WavData wd = readWav(geminiWav);
                                linePcm = resampleToMono44k(wd, targetSampleRate);
                            } else {
                                throw new RuntimeException("Gemini Voice (" + chosenOpt.geminiVoiceName + ") failed: " + errOut[0]);
                            }
                        } finally {
                            if (geminiWav.exists()) geminiWav.delete();
                        }
                    } else if (chosenOpt != null && chosenOpt.engineVoice != null) {
                        File wavFile = new File(getCacheDir(), "prev_dev_" + i + "_" + System.nanoTime() + ".wav");
                        try {
                            if (ttsReady && synthesizeToWav(seg.text, chosenOpt.engineVoice, styleIdx, wavFile)) {
                                WavData wd = readWav(wavFile);
                                linePcm = resampleToMono44k(wd, targetSampleRate);
                            } else {
                                throw new RuntimeException("Device Voice (" + chosenOpt.label + ") failed.");
                            }
                        } finally {
                            if (wavFile.exists()) wavFile.delete();
                        }
                    } else {
                        File mp3File = new File(getCacheDir(), "prev_free_" + i + "_" + System.nanoTime() + ".mp3");
                        try {
                            String shortLang = seg.isKhmer ? "km" : "en";
                            if (downloadFreeCloudTtsMp3(seg.text, shortLang, mp3File)) {
                                linePcm = decodeAudioFileToMono44k(mp3File, targetSampleRate);
                            } else {
                                throw new RuntimeException("Free Cloud Voice download failed.");
                            }
                        } finally {
                            if (mp3File.exists()) mp3File.delete();
                        }
                    }

                    long startSample = mergedMonoPcm.size();
                    for (short s : linePcm) mergedMonoPcm.add(s);
                    long endSample = mergedMonoPcm.size();

                    seg.startUs = (startSample * 1_000_000L) / targetSampleRate;
                    seg.endUs = (endSample * 1_000_000L) / targetSampleRate;

                    if (i < lines.size() - 1) {
                        int pauseSamples = (int) (targetSampleRate * 0.25);
                        for (int p = 0; p < pauseSamples; p++) mergedMonoPcm.add((short) 0);
                    }
                }

                int tailSamples = (int) (targetSampleRate * 0.5);
                for (int i = 0; i < tailSamples; i++) mergedMonoPcm.add((short) 0);

                // Render all video frames (background photo/color + text + highlight pills) once for both Preview & MP4 Export
                Map<Integer, Bitmap> stateFrames = new HashMap<>();
                stateFrames.put(-1, renderFrameForTimestamp(width, height, lines, -1, bgCol, bgPhotoCopy));
                for (int i = 0; i < lines.size(); i++) {
                    stateFrames.put(i, renderFrameForTimestamp(width, height, lines, i, bgCol, bgPhotoCopy));
                }

                PreparedPreview prep = new PreparedPreview();
                prep.width = width;
                prep.height = height;
                prep.lines = lines;
                prep.mergedMonoPcm = mergedMonoPcm;
                prep.sampleRate = targetSampleRate;
                prep.stateFrames = stateFrames;

                runOnUiThread(() -> {
                    markPreviewReady(prep);
                    refreshExactPreview(-1);
                    status.setText("Preview Ready! Playing synced voices + photo...");
                });

                // Write merged PCM to a temp WAV for synchronized playback right inside Preview
                previewWavFile = new File(getCacheDir(), "preview_play_" + System.nanoTime() + ".wav");
                byte[] pcmBytes = new byte[mergedMonoPcm.size() * 2];
                ByteBuffer bb = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN);
                for (short s : mergedMonoPcm) bb.putShort(s);
                writePcm16MonoAsWav(pcmBytes, targetSampleRate, previewWavFile);

                // Play the exact prepared audio while syncing the exact prepared video frames in real time!
                final MediaPlayer mp = new MediaPlayer();
                activeOnlinePlayer = mp;
                final CountDownLatch playLatch = new CountDownLatch(1);
                mp.setDataSource(previewWavFile.getAbsolutePath());
                mp.setOnCompletionListener(m -> playLatch.countDown());
                mp.setOnErrorListener((m, what, extra) -> {
                    playLatch.countDown();
                    return true;
                });
                mp.prepare();
                mp.start();

                int lastShownIdx = -2;
                while (mp.isPlaying() && !stopRequested) {
                    long posUs = mp.getCurrentPosition() * 1000L;
                    int activeIdx = -1;
                    for (int i = 0; i < lines.size(); i++) {
                        LineSegment seg = lines.get(i);
                        if (posUs >= seg.startUs && posUs <= seg.endUs) {
                            activeIdx = i;
                            break;
                        }
                    }
                    if (activeIdx != lastShownIdx) {
                        lastShownIdx = activeIdx;
                        final int showIdx = activeIdx;
                        runOnUiThread(() -> refreshExactPreview(showIdx));
                    }
                    try { Thread.sleep(40); } catch (InterruptedException ignored) {}
                }

                if (!stopRequested) {
                    playLatch.await(2, TimeUnit.SECONDS);
                }
                try {
                    if (mp.isPlaying()) mp.stop();
                    mp.release();
                } catch (Exception ignored) {}
                if (activeOnlinePlayer == mp) activeOnlinePlayer = null;

                runOnUiThread(() -> {
                    isWorking = false;
                    generateBtn.setEnabled(true);
                    refreshExactPreview(-1);
                    status.setText("Preview finished! Tap '2. Export MP4 from Preview' to save video.");
                });
            } catch (Exception e) {
                e.printStackTrace();
                final String err = e.getMessage() != null ? e.getMessage() : e.toString();
                runOnUiThread(() -> {
                    isWorking = false;
                    generateBtn.setEnabled(true);
                    invalidatePreparedPreview();
                    refreshExactPreview(-1);
                    status.setText("Preview error: " + err);
                });
            } finally {
                if (bgPhotoCopy != null && !bgPhotoCopy.isRecycled()) bgPhotoCopy.recycle();
                if (previewWavFile != null && previewWavFile.exists()) previewWavFile.delete();
            }
        }).start();
    }

    /**
     * Step 2: Exports MP4 directly from the already-generated `readyPreview` (exact voices + photo frames),
     * saves to Movies/EnglishKhmerVideoMaker/, and auto-deletes ALL temporary files afterwards!
     */
    private void exportMp4FromPreparedPreview() {
        if (isWorking) return;
        if (readyPreview == null || readyPreview.mergedMonoPcm == null || readyPreview.stateFrames == null) {
            status.setText("Please tap '1. Generate Preview (Voices + Photo)' first.");
            return;
        }

        stopAllAudio();
        refreshExactPreview(-1);

        final PreparedPreview prep = readyPreview;
        isWorking = true;
        exportBtn.setEnabled(false);
        generateBtn.setEnabled(false);
        status.setText("Exporting MP4 from generated Preview (Voices + Photo)...");

        new Thread(() -> {
            File tempMp4 = null;
            try {
                tempMp4 = new File(getCacheDir(), "export_" + System.currentTimeMillis() + ".mp4");
                encodePreparedPreviewToMp4(prep, tempMp4);

                String savedName = "EK_Video_" + System.currentTimeMillis() + ".mp4";
                String savedLocation = saveMp4ToMovies(tempMp4, savedName);

                runOnUiThread(() -> {
                    isWorking = false;
                    generateBtn.setEnabled(true);
                    exportBtn.setEnabled(true);
                    refreshExactPreview(-1);
                    status.setText("MP4 Saved & All Temp Files Deleted: " + savedLocation);
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("MP4 Export Ready")
                            .setMessage("Video exported from Preview (Voices + Photo) to:\n" + savedLocation + "\n\nAll temporary files have been auto-deleted.")
                            .setPositiveButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                e.printStackTrace();
                final String err = e.getMessage() != null ? e.getMessage() : e.toString();
                runOnUiThread(() -> {
                    isWorking = false;
                    generateBtn.setEnabled(true);
                    exportBtn.setEnabled(true);
                    status.setText("Export failed: " + err);
                });
            } finally {
                if (tempMp4 != null && tempMp4.exists()) tempMp4.delete();
                // Auto-delete ALL temporary files in cache directories after MP4 export is ready
                cleanAllTempFiles();
            }
        }).start();
    }

    private void encodePreparedPreviewToMp4(PreparedPreview prep, File outputMp4) throws Exception {
        int width = prep.width;
        int height = prep.height;
        List<LineSegment> lines = prep.lines;
        List<Short> mergedMonoPcm = prep.mergedMonoPcm;
        int targetSampleRate = prep.sampleRate;
        Map<Integer, Bitmap> stateBitmaps = prep.stateFrames;

        long durationUs = (mergedMonoPcm.size() * 1_000_000L) / targetSampleRate;
        int fps = 15;
        int totalVideoFrames = Math.max(15, (int) ((durationUs * fps) / 1_000_000L));

        MediaMuxer muxer = new MediaMuxer(outputMp4.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

        MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000);
        videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

        MediaCodec videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        Surface inputSurface = videoEncoder.createInputSurface();
        videoEncoder.start();

        MediaFormat audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, targetSampleRate, 1);
        audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 96_000);
        audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);

        MediaCodec audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        audioEncoder.start();

        List<ByteBuffer> videoSamples = new ArrayList<>();
        List<MediaCodec.BufferInfo> videoInfos = new ArrayList<>();
        final MediaFormat[] finalVFormat = {null};
        MediaCodec.BufferInfo vInfo = new MediaCodec.BufferInfo();

        for (int frame = 0; frame < totalVideoFrames; frame++) {
            long framePtsUs = (frame * 1_000_000L) / fps;
            int activeIdx = -1;
            for (int i = 0; i < lines.size(); i++) {
                LineSegment seg = lines.get(i);
                if (framePtsUs >= seg.startUs && framePtsUs <= seg.endUs) {
                    activeIdx = i;
                    break;
                }
            }

            Bitmap frameBmp = stateBitmaps.get(activeIdx);
            if (frameBmp == null || frameBmp.isRecycled()) {
                frameBmp = stateBitmaps.get(-1);
            }
            Canvas c = inputSurface.lockCanvas(null);
            c.drawBitmap(frameBmp, 0, 0, null);
            inputSurface.unlockCanvasAndPost(c);

            drainEncoder(videoEncoder, vInfo, false, videoSamples, videoInfos, fmt -> finalVFormat[0] = fmt);
        }
        videoEncoder.signalEndOfInputStream();
        drainEncoder(videoEncoder, vInfo, true, videoSamples, videoInfos, fmt -> finalVFormat[0] = fmt);
        videoEncoder.stop();
        videoEncoder.release();
        inputSurface.release();

        List<ByteBuffer> audioSamples = new ArrayList<>();
        List<MediaCodec.BufferInfo> audioInfos = new ArrayList<>();
        final MediaFormat[] finalAFormat = {null};
        MediaCodec.BufferInfo aInfo = new MediaCodec.BufferInfo();

        int pcmCursor = 0;
        int totalPcm = mergedMonoPcm.size();
        boolean audioInputDone = false;
        boolean audioOutputDone = false;

        while (!audioOutputDone) {
            if (!audioInputDone) {
                int inIdx = audioEncoder.dequeueInputBuffer(10_000);
                if (inIdx >= 0) {
                    ByteBuffer inBuf = audioEncoder.getInputBuffer(inIdx);
                    inBuf.clear();
                    int maxSamples = inBuf.remaining() / 2;
                    int count = Math.min(maxSamples, totalPcm - pcmCursor);
                    long ptsUs = (pcmCursor * 1_000_000L) / targetSampleRate;
                    if (count > 0) {
                        for (int i = 0; i < count; i++) {
                            inBuf.putShort(mergedMonoPcm.get(pcmCursor + i));
                        }
                        pcmCursor += count;
                        audioEncoder.queueInputBuffer(inIdx, 0, count * 2, ptsUs, 0);
                    } else {
                        audioEncoder.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        audioInputDone = true;
                    }
                }
            }

            int outIdx = audioEncoder.dequeueOutputBuffer(aInfo, 10_000);
            if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                finalAFormat[0] = audioEncoder.getOutputFormat();
            } else if (outIdx >= 0) {
                ByteBuffer encoded = audioEncoder.getOutputBuffer(outIdx);
                if ((aInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && aInfo.size > 0) {
                    encoded.position(aInfo.offset);
                    encoded.limit(aInfo.offset + aInfo.size);
                    ByteBuffer copy = ByteBuffer.allocateDirect(aInfo.size);
                    copy.put(encoded);
                    copy.flip();

                    MediaCodec.BufferInfo infoCopy = new MediaCodec.BufferInfo();
                    infoCopy.set(0, aInfo.size, aInfo.presentationTimeUs, aInfo.flags);
                    audioSamples.add(copy);
                    audioInfos.add(infoCopy);
                }
                audioEncoder.releaseOutputBuffer(outIdx, false);
                if ((aInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    audioOutputDone = true;
                }
            }
        }
        audioEncoder.stop();
        audioEncoder.release();

        if (finalVFormat[0] == null) throw new RuntimeException("Video encoder did not produce output format.");
        int videoTrackIndex = muxer.addTrack(finalVFormat[0]);
        int audioTrackIndex = -1;
        if (finalAFormat[0] != null && !audioSamples.isEmpty()) {
            audioTrackIndex = muxer.addTrack(finalAFormat[0]);
        }
        muxer.start();

        for (int i = 0; i < videoSamples.size(); i++) {
            muxer.writeSampleData(videoTrackIndex, videoSamples.get(i), videoInfos.get(i));
        }
        if (audioTrackIndex >= 0) {
            for (int i = 0; i < audioSamples.size(); i++) {
                muxer.writeSampleData(audioTrackIndex, audioSamples.get(i), audioInfos.get(i));
            }
        }

        muxer.stop();
        muxer.release();
    }

    private boolean synthesizeWithGeminiApi(String text, boolean isKhmer, String voiceName, int styleIdx, String apiKey, File outWav, String[] errorOut) {
        ensureModelsDiscovered(apiKey);
        List<String> modelList = new ArrayList<>();
        modelList.add("gemini-3.8-flash");
        modelList.add("gemini-3.8-flash-preview-tts");
        modelList.add("gemini-3.0-flash");
        modelList.add("gemini-2.5-flash-preview-tts");
        for (String m : discoveredModels) {
            if (!modelList.contains(m)) modelList.add(m);
        }

        String stylePrompt;
        if (styleIdx == 1) {
            stylePrompt = "Speak slowly, clearly, and gently like a teacher. Say ONLY this exact text:\n";
        } else if (styleIdx == 2) {
            stylePrompt = "Speak in a warm, calm, deep storyteller tone. Say ONLY this exact text:\n";
        } else if (styleIdx == 3) {
            stylePrompt = "Speak in an energetic, cheerful, bright tone. Say ONLY this exact text:\n";
        } else {
            stylePrompt = isKhmer
                    ? "Speak this Khmer text naturally with native Cambodian pronunciation. Say ONLY this exact text:\n"
                    : "Speak this English text naturally and warmly. Say ONLY this exact text:\n";
        }

        String lastErr = "";
        for (String model : modelList) {
            HttpURLConnection conn = null;
            try {
                String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + model
                        + ":generateContent?key=" + URLEncoder.encode(apiKey, "UTF-8");
                URL url = new URL(endpoint);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);

                JSONObject part = new JSONObject();
                part.put("text", stylePrompt + text);

                JSONArray parts = new JSONArray();
                parts.put(part);

                JSONObject content = new JSONObject();
                content.put("parts", parts);

                JSONArray contents = new JSONArray();
                contents.put(content);

                JSONArray modalities = new JSONArray();
                modalities.put("AUDIO");

                JSONObject prebuiltVoice = new JSONObject();
                prebuiltVoice.put("voiceName", voiceName);

                JSONObject voiceConfig = new JSONObject();
                voiceConfig.put("prebuiltVoiceConfig", prebuiltVoice);

                JSONObject speechConfig = new JSONObject();
                speechConfig.put("voiceConfig", voiceConfig);

                JSONObject genConfig = new JSONObject();
                genConfig.put("responseModalities", modalities);
                genConfig.put("speechConfig", speechConfig);

                JSONObject payload = new JSONObject();
                payload.put("contents", contents);
                payload.put("generationConfig", genConfig);

                byte[] bodyBytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(bodyBytes);
                }

                int code = conn.getResponseCode();
                if (code != 200) {
                    String errBody = readStream(conn.getErrorStream());
                    lastErr = "HTTP " + code;
                    try {
                        JSONObject eObj = new JSONObject(errBody);
                        if (eObj.has("error")) {
                            lastErr = eObj.getJSONObject("error").optString("message", lastErr);
                        }
                    } catch (Exception ignored) {}
                    continue;
                }

                String resp = readStream(conn.getInputStream());
                JSONObject json = new JSONObject(resp);
                JSONArray candidates = json.optJSONArray("candidates");
                if (candidates == null || candidates.length() == 0) continue;

                JSONObject cand0 = candidates.getJSONObject(0);
                JSONObject respContent = cand0.optJSONObject("content");
                if (respContent == null) continue;

                JSONArray respParts = respContent.optJSONArray("parts");
                if (respParts == null) continue;

                for (int p = 0; p < respParts.length(); p++) {
                    JSONObject pObj = respParts.getJSONObject(p);
                    if (pObj.has("inlineData")) {
                        JSONObject inlineData = pObj.getJSONObject("inlineData");
                        String mimeType = inlineData.optString("mimeType", "audio/L16;rate=24000");
                        String b64 = inlineData.optString("data", "");
                        if (b64.isEmpty()) continue;

                        byte[] rawBytes = Base64.decode(b64, Base64.DEFAULT);
                        if (mimeType.contains("wav")) {
                            try (FileOutputStream fos = new FileOutputStream(outWav)) {
                                fos.write(rawBytes);
                            }
                        } else {
                            int sampleRate = 24000;
                            int rateIdx = mimeType.indexOf("rate=");
                            if (rateIdx >= 0) {
                                String sub = mimeType.substring(rateIdx + 5).replaceAll("[^0-9].*", "");
                                if (!sub.isEmpty()) sampleRate = Integer.parseInt(sub);
                            }
                            writePcm16MonoAsWav(rawBytes, sampleRate, outWav);
                        }
                        if (outWav.exists() && outWav.length() > 44) return true;
                    }
                }
            } catch (Exception e) {
                lastErr = e.getMessage() != null ? e.getMessage() : e.toString();
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        if (errorOut != null && errorOut.length > 0) errorOut[0] = lastErr;
        return false;
    }

    private void writePcm16MonoAsWav(byte[] pcmBytes, int sampleRate, File outWav) throws IOException {
        int channels = 1;
        int bitsPerSample = 16;
        int byteRate = sampleRate * channels * (bitsPerSample / 8);
        int blockAlign = channels * (bitsPerSample / 8);
        int dataSize = pcmBytes.length;
        int chunkSize = 36 + dataSize;

        ByteBuffer header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        header.put(new byte[]{'R', 'I', 'F', 'F'});
        header.putInt(chunkSize);
        header.put(new byte[]{'W', 'A', 'V', 'E'});
        header.put(new byte[]{'f', 'm', 't', ' '});
        header.putInt(16);
        header.putShort((short) 1);
        header.putShort((short) channels);
        header.putInt(sampleRate);
        header.putInt(byteRate);
        header.putShort((short) blockAlign);
        header.putShort((short) bitsPerSample);
        header.put(new byte[]{'d', 'a', 't', 'a'});
        header.putInt(dataSize);

        try (FileOutputStream fos = new FileOutputStream(outWav)) {
            fos.write(header.array());
            fos.write(pcmBytes);
        }
    }

    private boolean downloadFreeCloudTtsMp3(String text, String langCode, File outMp3) {
        HttpURLConnection conn = null;
        try {
            String encoded = URLEncoder.encode(text, "UTF-8");
            String urlStr = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=" + langCode + "&q=" + encoded;
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(15000);
            if (conn.getResponseCode() != 200) return false;

            try (InputStream is = conn.getInputStream();
                 FileOutputStream fos = new FileOutputStream(outMp3)) {
                byte[] buf = new byte[4096];
                int len;
                while ((len = is.read(buf)) > 0) fos.write(buf, 0, len);
            }
            return outMp3.exists() && outMp3.length() > 256;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private short[] decodeAudioFileToMono44k(File audioFile, int targetSampleRate) {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec decoder = null;
        try {
            extractor.setDataSource(audioFile.getAbsolutePath());
            int audioTrack = -1;
            MediaFormat format = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat mf = extractor.getTrackFormat(i);
                String mime = mf.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    format = mf;
                    break;
                }
            }
            if (audioTrack < 0 || format == null) return new short[0];

            extractor.selectTrack(audioTrack);
            String mime = format.getString(MediaFormat.KEY_MIME);
            int srcSampleRate = format.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                    ? format.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 24000;
            int srcChannels = format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                    ? format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;

            decoder = MediaCodec.createDecoderByType(mime);
            decoder.configure(format, null, null, 0);
            decoder.start();

            List<Short> rawSamples = new ArrayList<>();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean sawInputEOS = false;
            boolean sawOutputEOS = false;

            while (!sawOutputEOS) {
                if (!sawInputEOS) {
                    int inIdx = decoder.dequeueInputBuffer(10_000);
                    if (inIdx >= 0) {
                        ByteBuffer inBuf = decoder.getInputBuffer(inIdx);
                        int sampleSize = extractor.readSampleData(inBuf, 0);
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            sawInputEOS = true;
                        } else {
                            long pts = extractor.getSampleTime();
                            decoder.queueInputBuffer(inIdx, 0, sampleSize, pts, 0);
                            extractor.advance();
                        }
                    }
                }

                int outIdx = decoder.dequeueOutputBuffer(info, 10_000);
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat outFmt = decoder.getOutputFormat();
                    if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        srcSampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    }
                    if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        srcChannels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    }
                } else if (outIdx >= 0) {
                    ByteBuffer outBuf = decoder.getOutputBuffer(outIdx);
                    if (info.size > 0 && outBuf != null) {
                        outBuf.position(info.offset);
                        outBuf.limit(info.offset + info.size);
                        ShortBuffer sb = outBuf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer();
                        while (sb.hasRemaining()) {
                            rawSamples.add(sb.get());
                        }
                    }
                    decoder.releaseOutputBuffer(outIdx, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        sawOutputEOS = true;
                    }
                }
            }

            int monoFrames = rawSamples.size() / Math.max(1, srcChannels);
            if (monoFrames <= 0) return new short[0];
            double ratio = (double) srcSampleRate / targetSampleRate;
            int outLen = (int) (monoFrames / ratio);
            short[] resampled = new short[outLen];
            for (int i = 0; i < outLen; i++) {
                int srcFrame = Math.min(monoFrames - 1, (int) (i * ratio));
                int sum = 0;
                for (int c = 0; c < srcChannels; c++) {
                    sum += rawSamples.get(srcFrame * srcChannels + c);
                }
                resampled[i] = (short) (sum / srcChannels);
            }
            return resampled;
        } catch (Exception e) {
            return new short[0];
        } finally {
            if (decoder != null) {
                try { decoder.stop(); decoder.release(); } catch (Exception ignored) {}
            }
            extractor.release();
        }
    }

    private void cleanAllTempFiles() {
        try {
            File cache = getCacheDir();
            if (cache != null && cache.isDirectory()) {
                File[] files = cache.listFiles();
                if (files != null) {
                    for (File f : files) {
                        deleteRecursive(f);
                    }
                }
            }
            File extCache = getExternalCacheDir();
            if (extCache != null && extCache.isDirectory()) {
                File[] files = extCache.listFiles();
                if (files != null) {
                    for (File f : files) {
                        deleteRecursive(f);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void deleteRecursive(File fileOrDir) {
        if (fileOrDir == null || !fileOrDir.exists()) return;
        if (fileOrDir.isDirectory()) {
            File[] children = fileOrDir.listFiles();
            if (children != null) {
                for (File child : children) deleteRecursive(child);
            }
        }
        try { fileOrDir.delete(); } catch (Exception ignored) {}
    }

    private short[] resampleToMono44k(WavData wd, int targetSampleRate) {
        int monoFrames = wd.pcm.length / wd.channels;
        if (monoFrames <= 0) return new short[0];
        double ratio = (double) wd.sampleRate / targetSampleRate;
        int outLen = (int) (monoFrames / ratio);
        short[] out = new short[outLen];
        for (int i = 0; i < outLen; i++) {
            int srcFrame = Math.min(monoFrames - 1, (int) (i * ratio));
            int sum = 0;
            for (int c = 0; c < wd.channels; c++) {
                sum += wd.pcm[srcFrame * wd.channels + c];
            }
            out[i] = (short) (sum / wd.channels);
        }
        return out;
    }

    private boolean synthesizeToWav(String text, Voice voice, int styleIdx, File outFile) {
        try {
            final CountDownLatch latch = new CountDownLatch(1);
            final boolean[] success = {false};
            final String uttId = "synth_" + System.nanoTime();

            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) {
                    if (uttId.equals(utteranceId)) {
                        success[0] = true;
                        latch.countDown();
                    }
                }
                @Override public void onError(String utteranceId) {
                    if (uttId.equals(utteranceId)) latch.countDown();
                }
            });

            applySpeakingStyle(styleIdx);
            tts.setVoice(voice);
            int res = tts.synthesizeToFile(text, new Bundle(), outFile, uttId);
            if (res != TextToSpeech.SUCCESS) return false;
            latch.await(25, TimeUnit.SECONDS);
            return success[0] && outFile.exists() && outFile.length() > 44;
        } catch (Exception e) {
            return false;
        }
    }

    private Bitmap renderFrameForTimestamp(int width, int height, List<LineSegment> lines, int activeLineIdx, int bgCol, Bitmap bgPhoto) {
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.drawColor(bgCol);

        if (bgPhoto != null && !bgPhoto.isRecycled()) {
            float scale = Math.max((float) width / bgPhoto.getWidth(), (float) height / bgPhoto.getHeight());
            float newW = bgPhoto.getWidth() * scale;
            float newH = bgPhoto.getHeight() * scale;
            float left = (width - newW) / 2f;
            float top = (height - newH) / 2f;
            RectF dst = new RectF(left, top, left + newW, top + newH);
            canvas.drawBitmap(bgPhoto, null, dst, new Paint(Paint.FILTER_BITMAP_FLAG));

            Paint dim = new Paint();
            dim.setColor(Color.argb(110, 0, 0, 0));
            canvas.drawRect(0, 0, width, height, dim);
        }

        boolean darkBg = (bgPhoto != null || bgCol == Color.BLACK || bgCol == Color.rgb(20, 65, 130));
        int normalFg = darkBg ? Color.WHITE : Color.BLACK;
        int dimFg = darkBg ? Color.argb(155, 255, 255, 255) : Color.argb(145, 0, 0, 0);
        int highlightBoxColor = Color.rgb(255, 214, 10);
        int highlightTextColor = Color.BLACK;

        int padX = (int) (width * 0.08f);
        int textWidth = width - (padX * 2);
        float baseFontSize = Math.max(34f, width * 0.048f);
        if (lines.size() > 6) baseFontSize *= 0.82f;
        if (lines.size() > 10) baseFontSize *= 0.75f;

        List<StaticLayout> layouts = new ArrayList<>();
        float lineSpacing = baseFontSize * 0.48f;
        float totalHeight = 0f;

        for (int i = 0; i < lines.size(); i++) {
            LineSegment seg = lines.get(i);
            boolean isActive = (i == activeLineIdx);

            TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            tp.setTextSize(seg.isKhmer ? baseFontSize * 1.05f : baseFontSize);
            tp.setColor(isActive ? highlightTextColor : (activeLineIdx >= 0 ? dimFg : normalFg));
            if (isActive || !seg.isKhmer) {
                tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            }

            StaticLayout sl = StaticLayout.Builder.obtain(seg.text, 0, seg.text.length(), tp, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .build();
            layouts.add(sl);
            totalHeight += sl.getHeight();
            if (i < lines.size() - 1) totalHeight += lineSpacing;
        }

        float curY = Math.max(padX, (height - totalHeight) / 2f);
        Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        boxPaint.setColor(highlightBoxColor);

        for (int i = 0; i < lines.size(); i++) {
            StaticLayout sl = layouts.get(i);
            float lh = sl.getHeight();

            if (i == activeLineIdx) {
                float maxLineW = 0f;
                for (int l = 0; l < sl.getLineCount(); l++) {
                    maxLineW = Math.max(maxLineW, sl.getLineWidth(l));
                }
                float boxPadX = 24f;
                float boxPadY = 10f;
                float boxLeft = Math.max(padX - 12f, (width - maxLineW) / 2f - boxPadX);
                float boxRight = Math.min(width - padX + 12f, (width + maxLineW) / 2f + boxPadX);
                RectF pill = new RectF(boxLeft, curY - boxPadY, boxRight, curY + lh + boxPadY);
                canvas.drawRoundRect(pill, 18f, 18f, boxPaint);
            }

            canvas.save();
            canvas.translate(padX, curY);
            sl.draw(canvas);
            canvas.restore();

            curY += lh + lineSpacing;
        }
        return bmp;
    }

    private static class WavData {
        short[] pcm;
        int sampleRate;
        int channels;
    }

    private WavData readWav(File file) throws IOException {
        byte[] bytes = new byte[(int) file.length()];
        try (FileInputStream fis = new FileInputStream(file)) {
            int offset = 0;
            while (offset < bytes.length) {
                int r = fis.read(bytes, offset, bytes.length - offset);
                if (r < 0) break;
                offset += r;
            }
        }
        ByteBuffer bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        int channels = 1;
        int sampleRate = 22050;
        int dataOffset = 44;
        int dataSize = bytes.length - 44;

        int pos = 12;
        while (pos + 8 <= bytes.length) {
            int chunkId = bb.getInt(pos);
            int chunkSize = bb.getInt(pos + 4);
            if (chunkId == 0x20746d66) {
                channels = bb.getShort(pos + 10) & 0xFFFF;
                sampleRate = bb.getInt(pos + 12);
            } else if (chunkId == 0x61746164) {
                dataOffset = pos + 8;
                dataSize = Math.min(chunkSize, bytes.length - dataOffset);
                break;
            }
            pos += 8 + chunkSize + (chunkSize % 2);
        }

        int numSamples = Math.max(0, dataSize / 2);
        short[] samples = new short[numSamples];
        bb.position(dataOffset);
        for (int i = 0; i < numSamples; i++) {
            samples[i] = bb.getShort();
        }
        WavData wd = new WavData();
        wd.pcm = samples;
        wd.sampleRate = sampleRate > 0 ? sampleRate : 22050;
        wd.channels = channels > 0 ? channels : 1;
        return wd;
    }

    private interface FormatCallback {
        void onFormat(MediaFormat format);
    }

    private void drainEncoder(MediaCodec encoder, MediaCodec.BufferInfo info, boolean endOfStream,
                              List<ByteBuffer> outSamples, List<MediaCodec.BufferInfo> outInfos,
                              FormatCallback formatCallback) {
        while (true) {
            int outIdx = encoder.dequeueOutputBuffer(info, 10_000);
            if (outIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break;
            } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                formatCallback.onFormat(encoder.getOutputFormat());
            } else if (outIdx >= 0) {
                ByteBuffer encoded = encoder.getOutputBuffer(outIdx);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                    encoded.position(info.offset);
                    encoded.limit(info.offset + info.size);
                    ByteBuffer copy = ByteBuffer.allocateDirect(info.size);
                    copy.put(encoded);
                    copy.flip();

                    MediaCodec.BufferInfo infoCopy = new MediaCodec.BufferInfo();
                    long pts = outSamples.size() * (1_000_000L / 15L);
                    infoCopy.set(0, info.size, pts, info.flags);
                    outSamples.add(copy);
                    outInfos.add(infoCopy);
                }
                encoder.releaseOutputBuffer(outIdx, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }

    private String saveMp4ToMovies(File sourceMp4, String displayName) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/EnglishKhmerVideoMaker");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            ContentResolver resolver = getContentResolver();
            Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Could not create MediaStore video entry.");

            try (OutputStream os = resolver.openOutputStream(uri);
                 FileInputStream fis = new FileInputStream(sourceMp4)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) > 0) os.write(buf, 0, len);
            }

            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return "Movies/EnglishKhmerVideoMaker/" + displayName;
        } else {
            File moviesDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "EnglishKhmerVideoMaker");
            if (!moviesDir.exists()) moviesDir.mkdirs();
            File dest = new File(moviesDir, displayName);
            try (FileInputStream fis = new FileInputStream(sourceMp4);
                 FileOutputStream fos = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) > 0) fos.write(buf, 0, len);
            }
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(dest)));
            return dest.getAbsolutePath();
        }
    }

    private VoiceOption selectedOption(List<VoiceOption> options, Spinner spinner) {
        int pos = spinner.getSelectedItemPosition();
        return pos >= 0 && pos < options.size() ? options.get(pos) : null;
    }

    private void pasteInto(EditText target) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence value = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (value != null) target.setText(value);
        } else {
            status.setText("Clipboard is empty.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PHOTO && resultCode == RESULT_OK && data != null) {
            backgroundPhoto = data.getData();
            try (InputStream is = getContentResolver().openInputStream(backgroundPhoto)) {
                if (cachedBgPhoto != null && !cachedBgPhoto.isRecycled()) cachedBgPhoto.recycle();
                cachedBgPhoto = BitmapFactory.decodeStream(is);
            } catch (Exception ignored) {
                cachedBgPhoto = null;
            }
            invalidatePreparedPreview();
            refreshExactPreview(-1);
            status.setText("Background photo selected. Tap '1. Generate Preview' to prepare.");
        }
    }

    private void section(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(17);
        t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(Color.rgb(35, 75, 145));
        t.setPadding(0, 20, 0, 8);
        root.addView(t);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private ArrayAdapter<String> adapter(List<String> values) {
        return new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
    }

    private ArrayAdapter<String> adapter(String[] values) {
        return new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
    }

    @Override
    protected void onDestroy() {
        stopAllAudio();
        invalidatePreparedPreview();
        cleanAllTempFiles();
        if (cachedBgPhoto != null && !cachedBgPhoto.isRecycled()) {
            cachedBgPhoto.recycle();
        }
        if (tts != null) {
            tts.shutdown();
        }
        super.onDestroy();
    }
}
